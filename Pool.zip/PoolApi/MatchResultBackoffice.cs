using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text.RegularExpressions;

namespace DrukDatabaseLayer
{
    public class MatchRuleDetails
    {
        public int MatchRulesId { get; set; }
        public int? PlayStyleId { get; set; }
        public string PlayStyle { get; set; }
        public int? PlayFrom { get; set; }
        public int? PlayTo { get; set; }
        public string Description { get; set; }
    }


    public class MatchVenueDetails
    {
        public int FacilityId { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public int AssignedOnMatchId { get; set; }
    }

    public class MatchScheduleDetails
    {
        public int ScheduleId { get; set; }
        public DateTime? FromTime { get; set; }
        public DateTime? ToTime { get; set; }
        public int AssignedOnMatchId { get; set; }
    }

    public class MatchSeatDetails
    {
        public int SeatId { get; set; }
        public int? PlayerId { get; set; }
        public string PlayerName { get; set; }
        public int? ResultMatchPlace { get; set; }
        public int? ResultPoints { get; set; }
        public int? Mmr { get; set; }
    }

    public class MatchDetails
    {
        public int MatchId { get; set; }
        public string MatchName { get; set; }
        public bool IndividualMatch { get; set; }
        public MatchRuleDetails MatchRules { get; set; }
        public MatchVenueDetails Venue { get; set; }
        public MatchScheduleDetails Schedule { get; set; }
        public List<MatchSeatDetails> Seats { get; set; } = new List<MatchSeatDetails>();
    }

    public class MatchResultUpdate
    {
        public int SeatId { get; set; }
        public int ResultMatchPlace { get; set; }
        public int? ResultPoints { get; set; }
    }

    public class MmrChangeDetails
    {
        public int RegisteredUserId { get; set; }
        public int PlayerId { get; set; }
        public string PlayerName { get; set; }
        public int Before { get; set; }
        public int Delta { get; set; }
        public int After { get; set; }
    }

    public class AdvancedPlayerDetails
    {
        public int PlayerId { get; set; }
        public string PlayerName { get; set; }
        public int Place { get; set; }
        public int DestinationSeatId { get; set; }
        public int DestinationMatchId { get; set; }
        public string DestinationMatchName { get; set; }
    }

    public class StageAdvanceResult
    {
        public int? StageMatchId { get; set; }
        public string StageName { get; set; }
        public bool StageComplete { get; set; }
        public bool PlacementResolved { get; set; }
        public string Message { get; set; }
        public List<AdvancedPlayerDetails> AdvancedPlayers { get; set; } = new List<AdvancedPlayerDetails>();
        public List<MmrChangeDetails> MmrChanges { get; set; } = new List<MmrChangeDetails>();
        public string MmrMessage { get; set; }
    }

    internal class StageSeatScore
    {
        public int SeatId { get; set; }
        public int PlayerId { get; set; }
        public string PlayerName { get; set; }
        public int Wins { get; set; }
        public int? ScoreDifference { get; set; }
        public int HeadToHeadWins { get; set; }
        public int Buchholz { get; set; }
        public bool HadBye { get; set; }
        public int? DirectPlace { get; set; }
        public int? DirectPoints { get; set; }
    }

    internal class ChildSeatResult
    {
        public int MatchId { get; set; }
        public int StageSeatId { get; set; }
        public int PlayerId { get; set; }
        public int? ResultMatchPlace { get; set; }
        public int? ResultPoints { get; set; }
    }

    internal class SwissMatchInfo
    {
        public int MatchId { get; set; }
        public int Round { get; set; }
        public int MatchRulesId { get; set; }
        public string MatchName { get; set; }
    }

    internal class SwissPair
    {
        public StageSeatScore First { get; set; }
        public StageSeatScore Second { get; set; }
    }

    internal class DestinationSeat
    {
        public int SeatId { get; set; }
        public int MatchId { get; set; }
        public string MatchName { get; set; }
        public int? PlayerId { get; set; }
    }

    public class ManualAdvancementPlayerDetails
    {
        public int PlayerId { get; set; }
        public string PlayerName { get; set; }
        public int? Place { get; set; }
    }

    public class ManualAdvancementDestinationDetails
    {
        public int SeatId { get; set; }
        public int MatchId { get; set; }
        public string MatchName { get; set; }
        public int? ParentMatchId { get; set; }
        public string ParentMatchName { get; set; }
        public int? AutoSelectPlace { get; set; }
        public int? PlayerId { get; set; }
        public string PlayerName { get; set; }
        public bool ConfiguredForSource { get; set; }
        public bool RequiresPlayerSwap { get; set; }
    }

    internal class ManualAdvancementSeatCandidate
    {
        public int SeatId { get; set; }
        public int MatchId { get; set; }
        public string MatchName { get; set; }
        public int? ParentMatchId { get; set; }
        public string ParentMatchName { get; set; }
        public int? AutoSelectMatchId { get; set; }
        public int? AutoSelectPlace { get; set; }
        public int? PlayerId { get; set; }
        public string PlayerName { get; set; }
    }

    internal class SeatRoutingDetails
    {
        public int SeatId { get; set; }
        public int MatchId { get; set; }
        public int? AutoSelectMatchId { get; set; }
        public int? AutoSelectPlace { get; set; }
        public int? PlayerId { get; set; }
    }

    public class ManualAdvancementState
    {
        public int SourceStageMatchId { get; set; }
        public string SourceStageName { get; set; }
        public bool StageComplete { get; set; }
        public List<ManualAdvancementPlayerDetails> Players { get; set; } = new List<ManualAdvancementPlayerDetails>();
        public List<ManualAdvancementDestinationDetails> Destinations { get; set; } = new List<ManualAdvancementDestinationDetails>();
    }

    public class ManualAdvancementAssignment
    {
        public int DestinationSeatId { get; set; }
        public int? PlayerId { get; set; }
    }

    public class ManualAdvancementSaveResult
    {
        public bool Saved { get; set; }
        public string Message { get; set; }
        public ManualAdvancementState State { get; set; }
    }

    public class StageManualAdvancementPlayerDetails
    {
        public int PlayerId { get; set; }
        public string PlayerName { get; set; }
        public int SourcePoolMatchId { get; set; }
        public string SourcePoolName { get; set; }
        public int Place { get; set; }
        public int SourcePoolPlayerCount { get; set; }
        public int TargetStageMatchId { get; set; }
        public string TargetStageName { get; set; }
        public int CurrentDestinationPoolMatchId { get; set; }
        public string CurrentDestinationPoolName { get; set; }
    }

    public class StageManualAdvancementPoolDetails
    {
        public int MatchId { get; set; }
        public string MatchName { get; set; }
        public int TargetStageMatchId { get; set; }
        public string TargetStageName { get; set; }
        public int Capacity { get; set; }
        public int CurrentAssignedCount { get; set; }
    }

    public class StageManualAdvancementState
    {
        public int SourceStageMatchId { get; set; }
        public string SourceStageName { get; set; }
        public bool StageComplete { get; set; }
        public List<StageManualAdvancementPlayerDetails> Players { get; set; } = new List<StageManualAdvancementPlayerDetails>();
        public List<StageManualAdvancementPoolDetails> Pools { get; set; } = new List<StageManualAdvancementPoolDetails>();
    }

    public class StageManualAdvancementAssignment
    {
        public int PlayerId { get; set; }
        public int DestinationPoolMatchId { get; set; }
    }

    public class StageManualAdvancementSaveResult
    {
        public bool Saved { get; set; }
        public string Message { get; set; }
        public StageManualAdvancementState State { get; set; }
    }

    internal class StageManualRouteRecord
    {
        public int SeatId { get; set; }
        public int SourcePoolMatchId { get; set; }
        public string SourcePoolName { get; set; }
        public int Place { get; set; }
        public int TargetStageMatchId { get; set; }
        public string TargetStageName { get; set; }
        public int DestinationPoolMatchId { get; set; }
        public string DestinationPoolName { get; set; }
        public int? PlayerId { get; set; }
        public string PlayerName { get; set; }
    }

    internal class StageManualCandidateSeat
    {
        public int SeatId { get; set; }
        public int MatchId { get; set; }
        public int TargetStageMatchId { get; set; }
        public int? AutoSelectMatchId { get; set; }
        public int? AutoSelectPlace { get; set; }
        public int? PlayerId { get; set; }
    }

    public class MatchResultBackoffice
    {
        private readonly IConfigurationRoot _configuration;

        public MatchResultBackoffice()
        {
            var builder = new ConfigurationBuilder()
                .SetBasePath(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location))
                .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true);

            _configuration = builder.Build();
        }

        public bool IsTournamentAdminForMatch(int matchId, int userId)
        {
            const string sql = @"
;WITH TournamentTree AS
(
    SELECT
        T.Id AS TournamentId,
        T.MatchId AS RootMatchId,
        T.Admin,
        M.Id AS MatchId,
        CAST('|'+ CAST(M.Id AS VARCHAR(20)) + '|' AS VARCHAR(MAX)) AS [Path]
    FROM Tournament T
    INNER JOIN [Match] M ON M.Id = T.MatchId
    WHERE T.Admin = @UserId

    UNION ALL

    SELECT
        TT.TournamentId,
        TT.RootMatchId,
        TT.Admin,
        M.Id,
        CAST(TT.[Path] + CAST(M.Id AS VARCHAR(20)) + '|' AS VARCHAR(MAX))
    FROM TournamentTree TT
    INNER JOIN [Match] M ON M.ParentMatchId = TT.MatchId
    WHERE M.Id <> TT.RootMatchId
      AND CHARINDEX('|' + CAST(M.Id AS VARCHAR(20)) + '|', TT.[Path]) = 0
)
SELECT COUNT(1)
FROM TournamentTree
WHERE MatchId = @MatchId
OPTION (MAXRECURSION 1000);";

            using (SqlConnection conn = new SqlConnection(_configuration["connectionstring"]))
            using (SqlCommand cmd = new SqlCommand(sql, conn))
            {
                cmd.Parameters.Add("@MatchId", SqlDbType.Int).Value = matchId;
                cmd.Parameters.Add("@UserId", SqlDbType.Int).Value = userId;
                conn.Open();
                return Convert.ToInt32(cmd.ExecuteScalar()) > 0;
            }
        }

        public bool CanEditMatchResults(int matchId, int userId)
        {
            const string sql = @"
;WITH TournamentTree AS
(
    SELECT
        T.Id AS TournamentId,
        T.MatchId AS RootMatchId,
        M.Id AS MatchId,
        CAST('|'+ CAST(M.Id AS VARCHAR(20)) + '|' AS VARCHAR(MAX)) AS [Path]
    FROM Tournament T
    INNER JOIN [Match] M ON M.Id = T.MatchId

    UNION ALL

    SELECT
        TT.TournamentId,
        TT.RootMatchId,
        M.Id,
        CAST(TT.[Path] + CAST(M.Id AS VARCHAR(20)) + '|' AS VARCHAR(MAX))
    FROM TournamentTree TT
    INNER JOIN [Match] M ON M.ParentMatchId = TT.MatchId
    WHERE M.Id <> TT.RootMatchId
      AND CHARINDEX('|' + CAST(M.Id AS VARCHAR(20)) + '|', TT.[Path]) = 0
)
SELECT COUNT(1)
FROM TournamentTree TT
INNER JOIN Tournament T ON T.Id = TT.TournamentId
LEFT JOIN TournamentMatchEditor E
    ON E.TournamentId = T.Id
   AND E.RegisteredUserId = @UserId
WHERE TT.MatchId = @MatchId
  AND (T.Admin = @UserId OR E.RegisteredUserId IS NOT NULL)
OPTION (MAXRECURSION 1000);";

            using (SqlConnection conn = new SqlConnection(_configuration["connectionstring"]))
            using (SqlCommand cmd = new SqlCommand(sql, conn))
            {
                cmd.Parameters.Add("@MatchId", SqlDbType.Int).Value = matchId;
                cmd.Parameters.Add("@UserId", SqlDbType.Int).Value = userId;
                conn.Open();
                return Convert.ToInt32(cmd.ExecuteScalar()) > 0;
            }
        }


        public ManualAdvancementState GetManualAdvancement(int sourceStageMatchId)
        {
            using (SqlConnection conn = new SqlConnection(_configuration["connectionstring"]))
            {
                conn.Open();
                using (SqlTransaction transaction = conn.BeginTransaction())
                {
                    try
                    {
                        string stageName = GetMatchName(conn, transaction, sourceStageMatchId);
                        if (stageName == null)
                        {
                            transaction.Rollback();
                            return null;
                        }

                        ManualAdvancementState state = new ManualAdvancementState
                        {
                            SourceStageMatchId = sourceStageMatchId,
                            SourceStageName = stageName,
                            StageComplete = IsStageCompleteForManualAdvancement(conn, transaction, sourceStageMatchId),
                            Players = GetManualAdvancementPlayers(conn, transaction, sourceStageMatchId),
                            Destinations = GetManualAdvancementDestinations(conn, transaction, sourceStageMatchId)
                        };

                        transaction.Commit();
                        return state;
                    }
                    catch
                    {
                        transaction.Rollback();
                        throw;
                    }
                }
            }
        }

        public ManualAdvancementSaveResult SaveManualAdvancement(
            int sourceStageMatchId,
            IList<ManualAdvancementAssignment> assignments)
        {
            if (assignments == null)
            {
                throw new ArgumentException("Manual advancement assignments are required.");
            }

            using (SqlConnection conn = new SqlConnection(_configuration["connectionstring"]))
            {
                conn.Open();
                using (SqlTransaction transaction = conn.BeginTransaction())
                {
                    try
                    {
                        string stageName = GetMatchName(conn, transaction, sourceStageMatchId);
                        if (stageName == null)
                        {
                            throw new InvalidOperationException("The source pool was not found.");
                        }

                        if (!IsStageCompleteForManualAdvancement(conn, transaction, sourceStageMatchId))
                        {
                            throw new InvalidOperationException("Finish all matches in this pool before choosing the destination pools.");
                        }

                        List<ManualAdvancementPlayerDetails> players =
                            GetManualAdvancementPlayers(conn, transaction, sourceStageMatchId);

                        List<ManualAdvancementDestinationDetails> configuredRoutes =
                            GetConfiguredManualAdvancementDestinations(conn, transaction, sourceStageMatchId);

                        List<ManualAdvancementDestinationDetails> destinations =
                            GetManualAdvancementDestinations(conn, transaction, sourceStageMatchId);

                        if (configuredRoutes.Count == 0 || destinations.Count == 0)
                        {
                            throw new InvalidOperationException("No next-stage pools are configured to receive players from this pool.");
                        }

                        HashSet<int> advancingPlaces = new HashSet<int>(
                            configuredRoutes
                                .Where(x => x.AutoSelectPlace.HasValue && x.AutoSelectPlace.Value > 0)
                                .Select(x => x.AutoSelectPlace.Value));

                        List<ManualAdvancementPlayerDetails> qualifiedPlayers = players
                            .Where(x => x.Place.HasValue && advancingPlaces.Contains(x.Place.Value))
                            .OrderBy(x => x.Place.Value)
                            .ThenBy(x => x.PlayerId)
                            .ToList();

                        if (qualifiedPlayers.Count == 0)
                        {
                            throw new InvalidOperationException("The advancing players could not be determined from the standings.");
                        }

                        if (assignments.Count != qualifiedPlayers.Count ||
                            assignments.Any(x => !x.PlayerId.HasValue))
                        {
                            throw new InvalidOperationException("Choose one destination pool for every qualified player.");
                        }

                        List<int> selectedPlayerIds = assignments
                            .Select(x => x.PlayerId.Value)
                            .ToList();

                        if (selectedPlayerIds.Distinct().Count() != selectedPlayerIds.Count)
                        {
                            throw new InvalidOperationException("A player can only be advanced once.");
                        }

                        HashSet<int> requiredPlayerIds =
                            new HashSet<int>(qualifiedPlayers.Select(x => x.PlayerId));
                        if (!requiredPlayerIds.SetEquals(selectedPlayerIds))
                        {
                            throw new InvalidOperationException(
                                "The standings decide who advances. Choose a destination pool for every qualified player without replacing them with another player.");
                        }

                        if (assignments.Select(x => x.DestinationSeatId).Distinct().Count() != assignments.Count)
                        {
                            throw new InvalidOperationException("Two players cannot use the same destination seat.");
                        }

                        Dictionary<int, ManualAdvancementDestinationDetails> destinationBySeat =
                            destinations
                                .GroupBy(x => x.SeatId)
                                .ToDictionary(x => x.Key, x => x.First());

                        foreach (ManualAdvancementAssignment assignment in assignments)
                        {
                            ManualAdvancementPlayerDetails player = qualifiedPlayers.First(
                                x => x.PlayerId == assignment.PlayerId.Value);

                            if (!destinationBySeat.TryGetValue(
                                    assignment.DestinationSeatId,
                                    out ManualAdvancementDestinationDetails destination) ||
                                destination.AutoSelectPlace != player.Place)
                            {
                                throw new InvalidOperationException(
                                    "The selected pool is not available for that player's qualifying place.");
                            }
                        }

                        Dictionary<int, ManualAdvancementDestinationDetails> currentRouteByPlace =
                            new Dictionary<int, ManualAdvancementDestinationDetails>();

                        foreach (ManualAdvancementPlayerDetails player in qualifiedPlayers)
                        {
                            List<ManualAdvancementDestinationDetails> routesForPlace = configuredRoutes
                                .Where(x => x.AutoSelectPlace == player.Place)
                                .ToList();

                            if (routesForPlace.Count != 1)
                            {
                                throw new InvalidOperationException(
                                    "This finishing place does not have exactly one configured next-stage route.");
                            }

                            currentRouteByPlace[player.Place.Value] = routesForPlace[0];
                        }

                        var plans = qualifiedPlayers.Select(player =>
                        {
                            ManualAdvancementAssignment assignment = assignments.First(
                                x => x.PlayerId == player.PlayerId);
                            ManualAdvancementDestinationDetails chosen =
                                destinationBySeat[assignment.DestinationSeatId];
                            ManualAdvancementDestinationDetails current =
                                currentRouteByPlace[player.Place.Value];

                            return new
                            {
                                Player = player,
                                Current = current,
                                Chosen = chosen,
                                Changed = current.SeatId != chosen.SeatId
                            };
                        }).ToList();

                        if (!plans.Any(x => x.Changed))
                        {
                            ManualAdvancementState unchangedState = new ManualAdvancementState
                            {
                                SourceStageMatchId = sourceStageMatchId,
                                SourceStageName = stageName,
                                StageComplete = true,
                                Players = players,
                                Destinations = destinations
                            };

                            transaction.Commit();
                            return new ManualAdvancementSaveResult
                            {
                                Saved = true,
                                Message = "The destination pools are already set that way.",
                                State = unchangedState
                            };
                        }

                        foreach (var plan in plans.Where(x => x.Changed))
                        {
                            SeatRoutingDetails target =
                                GetSeatRoutingDetails(conn, transaction, plan.Chosen.SeatId);

                            if (target == null)
                            {
                                throw new InvalidOperationException("One of the selected destination seats no longer exists.");
                            }
                        }

                        HashSet<int> invalidatedPools = new HashSet<int>();
                        foreach (var plan in plans.Where(x => x.Changed))
                        {
                            if (invalidatedPools.Add(plan.Current.MatchId))
                            {
                                ClearStageOutcomeAndDestinations(
                                    conn,
                                    transaction,
                                    plan.Current.MatchId,
                                    true,
                                    new HashSet<int>());
                            }

                            if (invalidatedPools.Add(plan.Chosen.MatchId))
                            {
                                ClearStageOutcomeAndDestinations(
                                    conn,
                                    transaction,
                                    plan.Chosen.MatchId,
                                    true,
                                    new HashSet<int>());
                            }
                        }

                        int changedCount = 0;

                        foreach (var plan in plans.Where(x => x.Changed))
                        {
                            SeatRoutingDetails current =
                                GetSeatRoutingDetails(conn, transaction, plan.Current.SeatId);
                            SeatRoutingDetails target =
                                GetSeatRoutingDetails(conn, transaction, plan.Chosen.SeatId);

                            if (current == null || target == null)
                            {
                                throw new InvalidOperationException("A destination route changed while it was being saved.");
                            }

                            SwapSeatAutoSelection(
                                conn,
                                transaction,
                                current,
                                target);

                            int? displacedPlayerId = target.PlayerId;

                            if (displacedPlayerId.HasValue &&
                                displacedPlayerId.Value != plan.Player.PlayerId)
                            {
                                SetPlayerOnSeatAndChildren(
                                    conn,
                                    transaction,
                                    current.SeatId,
                                    displacedPlayerId.Value);
                            }
                            else
                            {
                                ClearPlayerFromSeatAndChildren(
                                    conn,
                                    transaction,
                                    current.SeatId);
                            }

                            SetPlayerOnSeatAndChildren(
                                conn,
                                transaction,
                                target.SeatId,
                                plan.Player.PlayerId);

                            changedCount++;
                        }

                        ManualAdvancementState updatedState = new ManualAdvancementState
                        {
                            SourceStageMatchId = sourceStageMatchId,
                            SourceStageName = stageName,
                            StageComplete = true,
                            Players = GetManualAdvancementPlayers(conn, transaction, sourceStageMatchId),
                            Destinations = GetManualAdvancementDestinations(conn, transaction, sourceStageMatchId)
                        };

                        transaction.Commit();

                        return new ManualAdvancementSaveResult
                        {
                            Saved = true,
                            Message = changedCount + " destination pool assignment" +
                                (changedCount == 1 ? " was" : "s were") +
                                " updated.",
                            State = updatedState
                        };
                    }
                    catch
                    {
                        transaction.Rollback();
                        throw;
                    }
                }
            }
        }

        public StageManualAdvancementState GetStageManualAdvancement(int sourceStageMatchId)
        {
            using (SqlConnection conn = new SqlConnection(_configuration["connectionstring"]))
            {
                conn.Open();
                using (SqlTransaction transaction = conn.BeginTransaction())
                {
                    try
                    {
                        StageManualAdvancementState state =
                            BuildStageManualAdvancementState(conn, transaction, sourceStageMatchId);
                        transaction.Commit();
                        return state;
                    }
                    catch
                    {
                        transaction.Rollback();
                        throw;
                    }
                }
            }
        }

        public StageManualAdvancementSaveResult SaveStageManualAdvancement(
            int sourceStageMatchId,
            IList<StageManualAdvancementAssignment> assignments)
        {
            if (assignments == null)
            {
                throw new ArgumentException("Stage advancement assignments are required.");
            }

            using (SqlConnection conn = new SqlConnection(_configuration["connectionstring"]))
            {
                conn.Open();
                using (SqlTransaction transaction = conn.BeginTransaction())
                {
                    try
                    {
                        StageManualAdvancementState state =
                            BuildStageManualAdvancementState(conn, transaction, sourceStageMatchId);

                        if (state == null)
                        {
                            throw new InvalidOperationException("The stage was not found.");
                        }

                        if (!state.StageComplete)
                        {
                            throw new InvalidOperationException(
                                "Finish every pool in this stage before assigning the advancing players.");
                        }

                        List<StageManualRouteRecord> routes =
                            GetStageManualRouteRecords(conn, transaction, sourceStageMatchId);

                        if (routes.Count == 0)
                        {
                            throw new InvalidOperationException(
                                "This stage has no configured advancement routes.");
                        }

                        if (routes.Any(x => !x.PlayerId.HasValue))
                        {
                            throw new InvalidOperationException(
                                "One or more pool placements are still unresolved. Resolve the standings before assigning destination pools.");
                        }

                        List<int> requiredPlayerIds = routes
                            .Select(x => x.PlayerId.Value)
                            .Distinct()
                            .OrderBy(x => x)
                            .ToList();

                        if (assignments.Count != requiredPlayerIds.Count ||
                            assignments.Select(x => x.PlayerId).Distinct().Count() != assignments.Count ||
                            !new HashSet<int>(assignments.Select(x => x.PlayerId))
                                .SetEquals(requiredPlayerIds))
                        {
                            throw new InvalidOperationException(
                                "Choose one destination pool for every player who was not eliminated.");
                        }

                        Dictionary<int, StageManualRouteRecord> routeByPlayer = routes
                            .Where(x => x.PlayerId.HasValue)
                            .GroupBy(x => x.PlayerId.Value)
                            .ToDictionary(x => x.Key, x => x.First());

                        Dictionary<int, StageManualAdvancementPoolDetails> poolById = state.Pools
                            .GroupBy(x => x.MatchId)
                            .ToDictionary(x => x.Key, x => x.First());

                        foreach (StageManualAdvancementAssignment assignment in assignments)
                        {
                            StageManualRouteRecord route;
                            StageManualAdvancementPoolDetails pool;

                            if (!routeByPlayer.TryGetValue(assignment.PlayerId, out route) ||
                                !poolById.TryGetValue(assignment.DestinationPoolMatchId, out pool))
                            {
                                throw new InvalidOperationException(
                                    "One of the selected players or destination pools is no longer available.");
                            }

                            if (pool.TargetStageMatchId != route.TargetStageMatchId)
                            {
                                throw new InvalidOperationException(
                                    "A player can only be moved between pools in the stage they qualified for.");
                            }
                        }

                        Dictionary<int, StageManualAdvancementAssignment> assignmentByPlayer =
                            assignments.ToDictionary(x => x.PlayerId, x => x);

                        Dictionary<int, int> destinationCount = assignments
                            .GroupBy(x => x.DestinationPoolMatchId)
                            .ToDictionary(x => x.Key, x => x.Count());

                        List<StageManualCandidateSeat> candidates =
                            GetStageManualCandidateSeats(conn, transaction, sourceStageMatchId);

                        foreach (KeyValuePair<int, int> item in destinationCount)
                        {
                            int capacity = candidates.Count(x => x.MatchId == item.Key);
                            if (item.Value > capacity)
                            {
                                StageManualAdvancementPoolDetails pool = poolById[item.Key];
                                throw new InvalidOperationException(
                                    (pool.MatchName ?? "The selected pool") +
                                    " only has room for " + capacity +
                                    " advancing player" + (capacity == 1 ? "." : "s."));
                            }
                        }

                        Dictionary<int, int> destinationSeatByPlayer = new Dictionary<int, int>();
                        HashSet<int> usedSeatIds = new HashSet<int>();

                        // Preserve an existing route when the player stays in the same pool.
                        foreach (StageManualRouteRecord route in routes.Where(x => x.PlayerId.HasValue))
                        {
                            int chosenPoolId = assignmentByPlayer[route.PlayerId.Value].DestinationPoolMatchId;
                            if (chosenPoolId == route.DestinationPoolMatchId &&
                                candidates.Any(x => x.SeatId == route.SeatId))
                            {
                                destinationSeatByPlayer[route.PlayerId.Value] = route.SeatId;
                                usedSeatIds.Add(route.SeatId);
                            }
                        }

                        // Allocate all moved players into a free route slot in the chosen pool.
                        foreach (StageManualRouteRecord route in routes
                            .Where(x => x.PlayerId.HasValue && !destinationSeatByPlayer.ContainsKey(x.PlayerId.Value))
                            .OrderBy(x => x.TargetStageMatchId)
                            .ThenBy(x => assignmentByPlayer[x.PlayerId.Value].DestinationPoolMatchId)
                            .ThenBy(x => x.Place)
                            .ThenBy(x => x.SourcePoolMatchId))
                        {
                            int chosenPoolId = assignmentByPlayer[route.PlayerId.Value].DestinationPoolMatchId;
                            StageManualCandidateSeat seat = candidates
                                .Where(x => x.MatchId == chosenPoolId && !usedSeatIds.Contains(x.SeatId))
                                .OrderByDescending(x => x.AutoSelectMatchId.HasValue)
                                .ThenBy(x => x.SeatId)
                                .FirstOrDefault();

                            if (seat == null)
                            {
                                throw new InvalidOperationException(
                                    "There is not enough room in one of the selected destination pools.");
                            }

                            destinationSeatByPlayer[route.PlayerId.Value] = seat.SeatId;
                            usedSeatIds.Add(seat.SeatId);
                        }

                        bool changed = routes
                            .Where(x => x.PlayerId.HasValue)
                            .Any(x => destinationSeatByPlayer[x.PlayerId.Value] != x.SeatId);

                        if (!changed)
                        {
                            transaction.Commit();
                            return new StageManualAdvancementSaveResult
                            {
                                Saved = true,
                                Message = "The destination pools are already set that way.",
                                State = state
                            };
                        }

                        HashSet<int> affectedPools = new HashSet<int>();
                        foreach (StageManualRouteRecord route in routes.Where(x => x.PlayerId.HasValue))
                        {
                            int newSeatId = destinationSeatByPlayer[route.PlayerId.Value];
                            if (newSeatId == route.SeatId)
                            {
                                continue;
                            }

                            affectedPools.Add(route.DestinationPoolMatchId);
                            StageManualCandidateSeat target = candidates.First(x => x.SeatId == newSeatId);
                            affectedPools.Add(target.MatchId);
                        }

                        HashSet<int> visited = new HashSet<int>();
                        foreach (int poolId in affectedPools)
                        {
                            ClearStageOutcomeAndDestinations(
                                conn,
                                transaction,
                                poolId,
                                true,
                                visited);
                        }

                        List<StageManualRouteRecord> changedRoutes = routes
                            .Where(x =>
                                x.PlayerId.HasValue &&
                                destinationSeatByPlayer[x.PlayerId.Value] != x.SeatId)
                            .ToList();

                        HashSet<int> touchedSeatIds = new HashSet<int>(
                            changedRoutes.Select(x => x.SeatId));
                        foreach (StageManualRouteRecord route in changedRoutes)
                        {
                            touchedSeatIds.Add(destinationSeatByPlayer[route.PlayerId.Value]);
                        }

                        // Clear only the route slots participating in the rearrangement.
                        // Players who remain in an unaffected pool keep their existing
                        // seat and any already-entered results are left untouched.
                        foreach (int seatId in touchedSeatIds)
                        {
                            ClearPlayerFromSeatAndChildren(conn, transaction, seatId);
                            using (SqlCommand cmd = new SqlCommand(@"
UPDATE Seat
SET AutoSelectMatchId = NULL,
    AutoSelectlPlace = NULL
WHERE Id = @SeatId;", conn, transaction))
                            {
                                cmd.Parameters.Add("@SeatId", SqlDbType.Int).Value = seatId;
                                cmd.ExecuteNonQuery();
                            }
                        }

                        foreach (StageManualRouteRecord route in changedRoutes)
                        {
                            int targetSeatId = destinationSeatByPlayer[route.PlayerId.Value];

                            using (SqlCommand cmd = new SqlCommand(@"
UPDATE Seat
SET AutoSelectMatchId = @SourcePoolMatchId,
    AutoSelectlPlace = @Place
WHERE Id = @SeatId;", conn, transaction))
                            {
                                cmd.Parameters.Add("@SourcePoolMatchId", SqlDbType.Int).Value = route.SourcePoolMatchId;
                                cmd.Parameters.Add("@Place", SqlDbType.Int).Value = route.Place;
                                cmd.Parameters.Add("@SeatId", SqlDbType.Int).Value = targetSeatId;
                                cmd.ExecuteNonQuery();
                            }

                            SetPlayerOnSeatAndChildren(
                                conn,
                                transaction,
                                targetSeatId,
                                route.PlayerId.Value);
                        }

                        StageManualAdvancementState updated =
                            BuildStageManualAdvancementState(conn, transaction, sourceStageMatchId);

                        transaction.Commit();
                        return new StageManualAdvancementSaveResult
                        {
                            Saved = true,
                            Message = "Destination pools were updated for all " +
                                requiredPlayerIds.Count + " advancing players.",
                            State = updated
                        };
                    }
                    catch
                    {
                        transaction.Rollback();
                        throw;
                    }
                }
            }
        }

        public MatchDetails GetMatchDetails(int matchId)
        {
            const string sql = @"
SELECT
    M.Id AS MatchId,
    M.Name AS MatchName,
    M.IndividualMatch,
    MR.Id AS MatchRulesId,
    MR.PlayStyleId,
    PS.Description AS PlayStyle,
    MR.PlayFrom,
    MR.PlayTo,
    MR.Description AS MatchRuleDescription,
    SCH.Id AS ScheduleId,
    SCH.FromTime,
    SCH.ToTime,
    F.Id AS FacilityId,
    F.Name AS VenueName,
    F.Description AS VenueDescription,
    CASE
        WHEN M.ScheduleId IS NOT NULL THEN M.Id
        WHEN M.IndividualMatch = 1 AND PM.ScheduleId IS NOT NULL THEN PM.Id
        ELSE NULL
    END AS ScheduleAssignedOnMatchId,
    S.Id AS SeatId,
    S.PlayerId,
    P.Name AS PlayerName,
    S.ResultMatchPlace,
    S.ResultPoints,
    RU.Mmr AS PlayerMmr
FROM [Match] M
LEFT JOIN [Match] PM ON M.ParentMatchId = PM.Id
LEFT JOIN MatchRules MR ON M.MatchRulesId = MR.Id
LEFT JOIN PlayStyle PS ON MR.PlayStyleId = PS.Id
LEFT JOIN Schedule SCH
    ON SCH.Id = CASE
        WHEN M.ScheduleId IS NOT NULL THEN M.ScheduleId
        WHEN M.IndividualMatch = 1 THEN PM.ScheduleId
        ELSE NULL
    END
LEFT JOIN Facility F ON SCH.FacilityId = F.Id
LEFT JOIN Seat S ON S.MatchId = M.Id
LEFT JOIN Player P ON S.PlayerId = P.Id
OUTER APPLY
(
    SELECT TOP 1 TR.RegisteredUserId
    FROM TournamentRegistration TR
    WHERE TR.PlayerId = P.Id
      AND TR.Status = 'registered'
    ORDER BY TR.UpdatedAt DESC, TR.RegisteredAt DESC
) PLAYERREG
LEFT JOIN RegisteredUsers RU
    ON RU.RegisteredUserID = COALESCE(P.RegisteredUserID, PLAYERREG.RegisteredUserId)
WHERE M.Id = @MatchId
ORDER BY S.Id;";

            MatchDetails details = null;

            using (SqlConnection conn = new SqlConnection(_configuration["connectionstring"]))
            using (SqlCommand cmd = new SqlCommand(sql, conn))
            {
                cmd.Parameters.Add("@MatchId", SqlDbType.Int).Value = matchId;
                conn.Open();

                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        if (details == null)
                        {
                            details = new MatchDetails
                            {
                                MatchId = Convert.ToInt32(reader["MatchId"]),
                                MatchName = Convert.ToString(reader["MatchName"]),
                                IndividualMatch = Convert.ToBoolean(reader["IndividualMatch"])
                            };

                            if (reader["MatchRulesId"] != DBNull.Value)
                            {
                                details.MatchRules = new MatchRuleDetails
                                {
                                    MatchRulesId = Convert.ToInt32(reader["MatchRulesId"]),
                                    PlayStyleId = ToNullableInt(reader["PlayStyleId"]),
                                    PlayStyle = ToNullableString(reader["PlayStyle"]),
                                    PlayFrom = ToNullableInt(reader["PlayFrom"]),
                                    PlayTo = ToNullableInt(reader["PlayTo"]),
                                    Description = ToNullableString(reader["MatchRuleDescription"])
                                };
                            }

                            if (reader["ScheduleId"] != DBNull.Value)
                            {
                                details.Schedule = new MatchScheduleDetails
                                {
                                    ScheduleId = Convert.ToInt32(reader["ScheduleId"]),
                                    FromTime = ToNullableDateTime(reader["FromTime"]),
                                    ToTime = ToNullableDateTime(reader["ToTime"]),
                                    AssignedOnMatchId = Convert.ToInt32(reader["ScheduleAssignedOnMatchId"])
                                };
                            }

                            if (reader["FacilityId"] != DBNull.Value)
                            {
                                details.Venue = new MatchVenueDetails
                                {
                                    FacilityId = Convert.ToInt32(reader["FacilityId"]),
                                    Name = ToNullableString(reader["VenueName"]),
                                    Description = ToNullableString(reader["VenueDescription"]),
                                    AssignedOnMatchId = Convert.ToInt32(reader["ScheduleAssignedOnMatchId"])
                                };
                            }
                        }

                        if (reader["SeatId"] != DBNull.Value)
                        {
                            details.Seats.Add(new MatchSeatDetails
                            {
                                SeatId = Convert.ToInt32(reader["SeatId"]),
                                PlayerId = ToNullableInt(reader["PlayerId"]),
                                PlayerName = ToNullableString(reader["PlayerName"]),
                                ResultMatchPlace = ToNullableInt(reader["ResultMatchPlace"]),
                                ResultPoints = ToNullableInt(reader["ResultPoints"]),
                                Mmr = ToNullableInt(reader["PlayerMmr"])
                            });
                        }
                    }
                }
            }

            return details;
        }

        public StageAdvanceResult SaveMatchResultsAndAdvance(int matchId, IList<MatchResultUpdate> results)
        {
            if (results == null || results.Count == 0)
            {
                throw new ArgumentException("No results were supplied.");
            }

            using (SqlConnection conn = new SqlConnection(_configuration["connectionstring"]))
            {
                conn.Open();
                using (SqlTransaction transaction = conn.BeginTransaction())
                {
                    try
                    {
                        // If an earlier Swiss round is edited, every later Swiss pairing
                        // is no longer trustworthy. Remove later rounds first so they can
                        // be generated again from the corrected standings.
                        InvalidateFutureSwissRounds(conn, transaction, matchId);

                        // Re-saving a match must never award MMR twice. Undo any previous
                        // MMR change for this match before applying the new result.
                        UndoMmrForMatch(conn, transaction, matchId);
                        SaveMatchResults(conn, transaction, matchId, results);
                        string mmrMessage;
                        List<MmrChangeDetails> mmrChanges = ApplyMmrForMatch(conn, transaction, matchId, out mmrMessage);

                        StageAdvanceResult advancement = RecalculateParentStage(conn, transaction, matchId);
                        advancement.MmrChanges = mmrChanges;
                        advancement.MmrMessage = mmrMessage;
                        transaction.Commit();
                        return advancement;
                    }
                    catch
                    {
                        transaction.Rollback();
                        throw;
                    }
                }
            }
        }

        public StageAdvanceResult ClearMatchResultsAndDownstream(int matchId)
        {
            using (SqlConnection conn = new SqlConnection(_configuration["connectionstring"]))
            {
                conn.Open();
                using (SqlTransaction transaction = conn.BeginTransaction())
                {
                    try
                    {
                        int? stageMatchId = GetParentStageMatchId(conn, transaction, matchId);
                        InvalidateFutureSwissRounds(conn, transaction, matchId);
                        UndoMmrForMatch(conn, transaction, matchId);

                        using (SqlCommand cmd = new SqlCommand(@"
UPDATE Seat
SET ResultMatchPlace = NULL,
    ResultPoints = NULL
WHERE MatchId = @MatchId;", conn, transaction))
                        {
                            cmd.Parameters.Add("@MatchId", SqlDbType.Int).Value = matchId;
                            cmd.ExecuteNonQuery();
                        }

                        StageAdvanceResult result = new StageAdvanceResult
                        {
                            StageMatchId = stageMatchId,
                            StageComplete = false,
                            PlacementResolved = false,
                            Message = "Result cleared."
                        };

                        if (stageMatchId.HasValue)
                        {
                            result.StageName = GetMatchName(conn, transaction, stageMatchId.Value);
                            ClearStageOutcomeAndDestinations(
                                conn,
                                transaction,
                                stageMatchId.Value,
                                false,
                                new HashSet<int>());
                            result.Message = "Result cleared. The stage is no longer complete, so its advanced players were removed from later seats.";
                        }

                        transaction.Commit();
                        return result;
                    }
                    catch
                    {
                        transaction.Rollback();
                        throw;
                    }
                }
            }
        }

        private static void SaveMatchResults(
            SqlConnection conn,
            SqlTransaction transaction,
            int matchId,
            IList<MatchResultUpdate> results)
        {
            const string sql = @"
UPDATE Seat
SET ResultMatchPlace = @ResultMatchPlace,
    ResultPoints = @ResultPoints
WHERE Id = @SeatId
  AND MatchId = @MatchId;";

            foreach (MatchResultUpdate result in results)
            {
                using (SqlCommand cmd = new SqlCommand(sql, conn, transaction))
                {
                    cmd.Parameters.Add("@MatchId", SqlDbType.Int).Value = matchId;
                    cmd.Parameters.Add("@SeatId", SqlDbType.Int).Value = result.SeatId;
                    cmd.Parameters.Add("@ResultMatchPlace", SqlDbType.Int).Value = result.ResultMatchPlace;

                    SqlParameter points = cmd.Parameters.Add("@ResultPoints", SqlDbType.Int);
                    points.Value = result.ResultPoints.HasValue
                        ? (object)result.ResultPoints.Value
                        : DBNull.Value;

                    int changed = cmd.ExecuteNonQuery();
                    if (changed != 1)
                    {
                        throw new InvalidOperationException("A seat does not belong to the selected match.");
                    }
                }
            }
        }

        private static List<MmrChangeDetails> ApplyMmrForMatch(
            SqlConnection conn,
            SqlTransaction transaction,
            int matchId,
            out string mmrMessage)
        {
            const int kFactor = 32;
            const double ratingScale = 400.0;

            List<(int PlayerId, int? UserId, string PlayerName, int Place, int? Mmr)> players =
                new List<(int PlayerId, int? UserId, string PlayerName, int Place, int? Mmr)>();

            // Prefer Player.RegisteredUserID, but also fall back to the active
            // TournamentRegistration. This makes MMR work for older tournaments
            // where the registration exists but the Player row was not linked correctly.
            using (SqlCommand cmd = new SqlCommand(@"
SELECT
    P.Id AS PlayerId,
    COALESCE(P.RegisteredUserID, REG.RegisteredUserId) AS RegisteredUserID,
    P.Name AS PlayerName,
    S.ResultMatchPlace,
    RU.Mmr
FROM Seat S
INNER JOIN Player P ON P.Id = S.PlayerId
OUTER APPLY
(
    SELECT TOP 1 TR.RegisteredUserId
    FROM TournamentRegistration TR
    WHERE TR.PlayerId = P.Id
      AND TR.Status = 'registered'
    ORDER BY TR.UpdatedAt DESC, TR.RegisteredAt DESC
) REG
LEFT JOIN RegisteredUsers RU
    ON RU.RegisteredUserID = COALESCE(P.RegisteredUserID, REG.RegisteredUserId)
WHERE S.MatchId = @MatchId
  AND S.PlayerId IS NOT NULL
  AND S.ResultMatchPlace IS NOT NULL
ORDER BY S.Id;", conn, transaction))
            {
                cmd.Parameters.Add("@MatchId", SqlDbType.Int).Value = matchId;
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        players.Add((
                            Convert.ToInt32(reader["PlayerId"]),
                            reader["RegisteredUserID"] == DBNull.Value ? (int?)null : Convert.ToInt32(reader["RegisteredUserID"]),
                            Convert.ToString(reader["PlayerName"]),
                            Convert.ToInt32(reader["ResultMatchPlace"]),
                            reader["Mmr"] == DBNull.Value ? (int?)null : Convert.ToInt32(reader["Mmr"])));
                    }
                }
            }

            if (players.Count != 2)
            {
                mmrMessage = "MMR was not changed because MMR is only calculated for 1v1 matches.";
                return new List<MmrChangeDetails>();
            }

            if (players.Any(x => !x.UserId.HasValue))
            {
                mmrMessage = "MMR was not changed because both players must be registered users.";
                return new List<MmrChangeDetails>();
            }

            if (players.Select(x => x.UserId.Value).Distinct().Count() != 2)
            {
                mmrMessage = "MMR was not changed because a player cannot play an MMR match against the same user account.";
                return new List<MmrChangeDetails>();
            }

            if (players.Any(x => !x.Mmr.HasValue))
            {
                mmrMessage = "MMR was not changed because one or both registered users do not have an MMR value.";
                return new List<MmrChangeDetails>();
            }

            var winner = players.SingleOrDefault(x => x.Place == 1);
            if (!winner.UserId.HasValue)
            {
                mmrMessage = "MMR was not changed because the match does not have exactly one winner.";
                return new List<MmrChangeDetails>();
            }

            var loser = players.Single(x => x.UserId.Value != winner.UserId.Value);

            // Elo-style MMR. A win over a stronger opponent is worth more; a win
            // over a weaker opponent is worth less. K=32 gives:
            // 1000 vs 1000  -> about +/-16
            // 1000 beats 1200 -> about +24/-24
            // 1200 beats 1000 -> about +8/-8
            double expectedWinner = 1.0 /
                (1.0 + Math.Pow(10.0, (loser.Mmr.Value - winner.Mmr.Value) / ratingScale));

            int ratingChange = (int)Math.Round(
                kFactor * (1.0 - expectedWinner),
                MidpointRounding.AwayFromZero);

            // A completed win/loss should always move the rating at least one point.
            ratingChange = Math.Max(1, ratingChange);

            List<MmrChangeDetails> changes = new List<MmrChangeDetails>();
            changes.Add(ApplyMmrDelta(
                conn, transaction, matchId, winner.PlayerId, winner.UserId.Value,
                winner.PlayerName, ratingChange));
            changes.Add(ApplyMmrDelta(
                conn, transaction, matchId, loser.PlayerId, loser.UserId.Value,
                loser.PlayerName, -ratingChange));

            mmrMessage = "MMR updated using Elo (K=32). The rating change is based on the two players' MMR before the match.";
            return changes;
        }

        private static MmrChangeDetails ApplyMmrDelta(
            SqlConnection conn,
            SqlTransaction transaction,
            int matchId,
            int playerId,
            int userId,
            string playerName,
            int requestedDelta)
        {
            int before;
            using (SqlCommand cmd = new SqlCommand(@"
SELECT Mmr
FROM RegisteredUsers WITH (UPDLOCK, HOLDLOCK)
WHERE RegisteredUserID = @UserId;", conn, transaction))
            {
                cmd.Parameters.Add("@UserId", SqlDbType.Int).Value = userId;
                object value = cmd.ExecuteScalar();
                if (value == null || value == DBNull.Value)
                {
                    throw new InvalidOperationException("A registered player could not be found while updating MMR.");
                }
                before = Convert.ToInt32(value);
            }

            int after = before + requestedDelta;
            int actualDelta = after - before;

            using (SqlCommand cmd = new SqlCommand(@"
UPDATE RegisteredUsers
SET Mmr = @After
WHERE RegisteredUserID = @UserId;

INSERT INTO MatchMmrChange
(
    MatchId,
    RegisteredUserId,
    PlayerId,
    Delta,
    MmrBefore,
    MmrAfter,
    CreatedAt
)
VALUES
(
    @MatchId,
    @UserId,
    @PlayerId,
    @Delta,
    @Before,
    @After,
    SYSDATETIME()
);", conn, transaction))
            {
                cmd.Parameters.Add("@MatchId", SqlDbType.Int).Value = matchId;
                cmd.Parameters.Add("@UserId", SqlDbType.Int).Value = userId;
                cmd.Parameters.Add("@PlayerId", SqlDbType.Int).Value = playerId;
                cmd.Parameters.Add("@Delta", SqlDbType.Int).Value = actualDelta;
                cmd.Parameters.Add("@Before", SqlDbType.Int).Value = before;
                cmd.Parameters.Add("@After", SqlDbType.Int).Value = after;
                cmd.ExecuteNonQuery();
            }

            return new MmrChangeDetails
            {
                RegisteredUserId = userId,
                PlayerId = playerId,
                PlayerName = playerName,
                Before = before,
                Delta = actualDelta,
                After = after
            };
        }

        private static void UndoMmrForMatch(
            SqlConnection conn,
            SqlTransaction transaction,
            int matchId)
        {
            List<(int UserId, int Delta)> changes = new List<(int UserId, int Delta)>();

            using (SqlCommand cmd = new SqlCommand(@"
SELECT RegisteredUserId, Delta
FROM MatchMmrChange WITH (UPDLOCK, HOLDLOCK)
WHERE MatchId = @MatchId;", conn, transaction))
            {
                cmd.Parameters.Add("@MatchId", SqlDbType.Int).Value = matchId;
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        changes.Add((
                            Convert.ToInt32(reader["RegisteredUserId"]),
                            Convert.ToInt32(reader["Delta"])));
                    }
                }
            }

            foreach (var change in changes)
            {
                using (SqlCommand cmd = new SqlCommand(@"
UPDATE RegisteredUsers
SET Mmr = Mmr - @Delta
WHERE RegisteredUserID = @UserId;", conn, transaction))
                {
                    cmd.Parameters.Add("@UserId", SqlDbType.Int).Value = change.UserId;
                    cmd.Parameters.Add("@Delta", SqlDbType.Int).Value = change.Delta;
                    cmd.ExecuteNonQuery();
                }
            }

            if (changes.Count > 0)
            {
                using (SqlCommand cmd = new SqlCommand(@"
DELETE FROM MatchMmrChange
WHERE MatchId = @MatchId;", conn, transaction))
                {
                    cmd.Parameters.Add("@MatchId", SqlDbType.Int).Value = matchId;
                    cmd.ExecuteNonQuery();
                }
            }
        }

        private static void UndoMmrForStageChildMatches(
            SqlConnection conn,
            SqlTransaction transaction,
            int stageMatchId)
        {
            List<int> matchIds = new List<int>();
            using (SqlCommand cmd = new SqlCommand(@"
SELECT Id
FROM [Match]
WHERE ParentMatchId = @StageMatchId
  AND IndividualMatch = 1;", conn, transaction))
            {
                cmd.Parameters.Add("@StageMatchId", SqlDbType.Int).Value = stageMatchId;
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        matchIds.Add(Convert.ToInt32(reader["Id"]));
                    }
                }
            }

            foreach (int childMatchId in matchIds)
            {
                UndoMmrForMatch(conn, transaction, childMatchId);
            }
        }

        private StageAdvanceResult RecalculateParentStage(
            SqlConnection conn,
            SqlTransaction transaction,
            int individualMatchId)
        {
            int? stageMatchId = GetParentStageMatchId(conn, transaction, individualMatchId);
            if (!stageMatchId.HasValue)
            {
                return new StageAdvanceResult
                {
                    StageComplete = false,
                    PlacementResolved = false,
                    Message = "Result saved. This match has no parent stage to advance from."
                };
            }

            int stageId = stageMatchId.Value;
            string stageName = GetMatchName(conn, transaction, stageId);
            List<StageSeatScore> stageSeats = GetStageSeats(conn, transaction, stageId);
            List<ChildSeatResult> childResults = GetChildResults(conn, transaction, stageId);
            List<int> childMatchIds = GetChildMatchIds(conn, transaction, stageId);

            StageAdvanceResult response = new StageAdvanceResult
            {
                StageMatchId = stageId,
                StageName = stageName,
                StageComplete = false,
                PlacementResolved = false
            };

            if (IsSwissStage(conn, transaction, stageId))
            {
                return RecalculateSwissStage(conn, transaction, stageId, stageName);
            }

            if (stageSeats.Count < 2 || childMatchIds.Count == 0)
            {
                ClearStageOutcomeAndDestinations(conn, transaction, stageId, false, new HashSet<int>());
                response.Message = "Result saved. The stage is still waiting for players or matches.";
                return response;
            }

            foreach (int childMatchId in childMatchIds)
            {
                List<ChildSeatResult> seats = childResults
                    .Where(x => x.MatchId == childMatchId && x.PlayerId > 0)
                    .ToList();

                if (seats.Count < 2 || seats.Any(x => !x.ResultMatchPlace.HasValue))
                {
                    ClearStageOutcomeAndDestinations(conn, transaction, stageId, false, new HashSet<int>());
                    response.Message = "Result saved. The stage is not complete yet; no players are advanced until every match in the stage has a result.";
                    return response;
                }
            }

            response.StageComplete = true;

            int? playFrom = GetPlayFrom(conn, transaction, stageId);
            int? playTo = GetPlayTo(conn, transaction, stageId);

            List<StageSeatScore> ranked;
            string unresolvedReason;
            if (!TryRankStage(stageSeats, childResults, childMatchIds, playFrom, playTo, out ranked, out unresolvedReason))
            {
                ClearStageOutcomeAndDestinations(conn, transaction, stageId, false, new HashSet<int>());
                response.Message = "All matches are complete, but the stage placement is tied. " + unresolvedReason;
                return response;
            }

            response.PlacementResolved = true;
            SaveStagePlacements(conn, transaction, ranked);
            response.AdvancedPlayers = MovePlayersToDestinationSeats(conn, transaction, stageId, ranked);

            if (response.AdvancedPlayers.Count == 0)
            {
                response.Message = "Stage complete. Placements were saved; no configured seats receive players from this stage.";
            }
            else
            {
                response.Message = "Stage complete. Placements were saved and " +
                    response.AdvancedPlayers.Count + " player" +
                    (response.AdvancedPlayers.Count == 1 ? " was" : "s were") +
                    " moved to the configured next-stage seat" +
                    (response.AdvancedPlayers.Count == 1 ? "." : "s.");
            }

            return response;
        }


        private static bool IsSwissStage(
            SqlConnection conn,
            SqlTransaction transaction,
            int stageMatchId)
        {
            using (SqlCommand cmd = new SqlCommand(@"
SELECT TOP 1 1
FROM [Match] M
INNER JOIN MatchRules MR ON MR.Id = M.MatchRulesId
WHERE M.ParentMatchId = @StageMatchId
  AND M.IndividualMatch = 1
  AND MR.PlayStyleId = 2;", conn, transaction))
            {
                cmd.Parameters.Add("@StageMatchId", SqlDbType.Int).Value = stageMatchId;
                object value = cmd.ExecuteScalar();
                return value != null && value != DBNull.Value;
            }
        }

        private static int GetSwissTotalRounds(
            SqlConnection conn,
            SqlTransaction transaction,
            int stageMatchId,
            int playerCount)
        {
            string description = null;

            using (SqlCommand cmd = new SqlCommand(@"
SELECT TOP 1 MR.Description
FROM [Match] M
INNER JOIN MatchRules MR ON MR.Id = M.MatchRulesId
WHERE M.ParentMatchId = @StageMatchId
  AND M.IndividualMatch = 1
  AND MR.PlayStyleId = 2
ORDER BY M.Id;", conn, transaction))
            {
                cmd.Parameters.Add("@StageMatchId", SqlDbType.Int).Value = stageMatchId;
                object value = cmd.ExecuteScalar();
                if (value != null && value != DBNull.Value)
                {
                    description = Convert.ToString(value);
                }
            }

            if (!String.IsNullOrWhiteSpace(description))
            {
                System.Text.RegularExpressions.Match parsed = Regex.Match(
                    description,
                    @"Swiss\s+system:\s*(\d+)\s*rounds?",
                    RegexOptions.IgnoreCase);

                if (parsed.Success)
                {
                    int configured;
                    if (Int32.TryParse(parsed.Groups[1].Value, out configured) && configured > 0)
                    {
                        return configured;
                    }
                }
            }

            return Math.Max(
                1,
                (int)Math.Ceiling(Math.Log(Math.Max(2, playerCount), 2)));
        }

        private static int ParseSwissRound(string matchName)
        {
            if (String.IsNullOrWhiteSpace(matchName))
            {
                return 0;
            }

            System.Text.RegularExpressions.Match parsed = Regex.Match(
                matchName,
                @"Swiss\s+round\s+(\d+)",
                RegexOptions.IgnoreCase);

            int round;
            return parsed.Success && Int32.TryParse(parsed.Groups[1].Value, out round)
                ? round
                : 0;
        }

        private static List<SwissMatchInfo> GetSwissMatches(
            SqlConnection conn,
            SqlTransaction transaction,
            int stageMatchId)
        {
            List<SwissMatchInfo> result = new List<SwissMatchInfo>();

            using (SqlCommand cmd = new SqlCommand(@"
SELECT M.Id, M.Name, M.MatchRulesId
FROM [Match] M
INNER JOIN MatchRules MR ON MR.Id = M.MatchRulesId
WHERE M.ParentMatchId = @StageMatchId
  AND M.IndividualMatch = 1
  AND MR.PlayStyleId = 2
ORDER BY M.Id;", conn, transaction))
            {
                cmd.Parameters.Add("@StageMatchId", SqlDbType.Int).Value = stageMatchId;

                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        string name = reader["Name"] == DBNull.Value
                            ? null
                            : Convert.ToString(reader["Name"]);

                        int round = ParseSwissRound(name);
                        if (round <= 0)
                        {
                            continue;
                        }

                        result.Add(new SwissMatchInfo
                        {
                            MatchId = Convert.ToInt32(reader["Id"]),
                            MatchRulesId = Convert.ToInt32(reader["MatchRulesId"]),
                            MatchName = name,
                            Round = round
                        });
                    }
                }
            }

            return result;
        }

        private static int GetSwissRoundForMatch(
            SqlConnection conn,
            SqlTransaction transaction,
            int matchId)
        {
            using (SqlCommand cmd = new SqlCommand(@"
SELECT Name
FROM [Match]
WHERE Id = @MatchId;", conn, transaction))
            {
                cmd.Parameters.Add("@MatchId", SqlDbType.Int).Value = matchId;
                object value = cmd.ExecuteScalar();
                return ParseSwissRound(value == null || value == DBNull.Value
                    ? null
                    : Convert.ToString(value));
            }
        }

        private static string GetSwissRoundStageName(
            SqlConnection conn,
            SqlTransaction transaction,
            int stageMatchId)
        {
            using (SqlCommand cmd = new SqlCommand(@"
SELECT COALESCE(P.Name, S.Name)
FROM [Match] S
LEFT JOIN [Match] P ON P.Id = S.ParentMatchId
WHERE S.Id = @StageMatchId;", conn, transaction))
            {
                cmd.Parameters.Add("@StageMatchId", SqlDbType.Int).Value = stageMatchId;
                object value = cmd.ExecuteScalar();
                return value == null || value == DBNull.Value
                    ? "Swiss"
                    : Convert.ToString(value);
            }
        }

        private static List<StageSeatScore> BuildSwissStandings(
            List<StageSeatScore> stageSeats,
            List<ChildSeatResult> childResults,
            List<SwissMatchInfo> swissMatches,
            int? playTo)
        {
            Dictionary<int, StageSeatScore> bySeat =
                stageSeats.ToDictionary(x => x.SeatId, x => x);

            Dictionary<int, List<int>> opponents =
                stageSeats.ToDictionary(x => x.SeatId, x => new List<int>());

            Dictionary<int, int> accumulatedScores =
                stageSeats.ToDictionary(x => x.SeatId, x => 0);

            Dictionary<int, bool> scoreAvailable =
                stageSeats.ToDictionary(x => x.SeatId, x => true);

            foreach (StageSeatScore seat in stageSeats)
            {
                seat.Wins = 0;
                seat.Buchholz = 0;
                seat.HeadToHeadWins = 0;
                seat.HadBye = false;
                seat.ScoreDifference = 0;
            }

            foreach (SwissMatchInfo match in swissMatches)
            {
                List<ChildSeatResult> seats = childResults
                    .Where(x => x.MatchId == match.MatchId && x.PlayerId > 0)
                    .ToList();

                if (seats.Count == 1)
                {
                    ChildSeatResult bye = seats[0];
                    StageSeatScore byeStanding;
                    if (bySeat.TryGetValue(bye.StageSeatId, out byeStanding))
                    {
                        if (bye.ResultMatchPlace == 1)
                        {
                            byeStanding.Wins++;
                        }
                        byeStanding.HadBye = true;
                    }
                    continue;
                }

                foreach (ChildSeatResult own in seats)
                {
                    StageSeatScore standing;
                    if (!bySeat.TryGetValue(own.StageSeatId, out standing))
                    {
                        continue;
                    }

                    if (own.ResultMatchPlace == 1)
                    {
                        standing.Wins++;
                    }

                    List<ChildSeatResult> matchOpponents = seats
                        .Where(x => x.StageSeatId != own.StageSeatId)
                        .ToList();

                    foreach (ChildSeatResult opponent in matchOpponents)
                    {
                        opponents[own.StageSeatId].Add(opponent.StageSeatId);
                    }

                    if (own.ResultPoints.HasValue)
                    {
                        accumulatedScores[own.StageSeatId] += own.ResultPoints.Value;
                    }
                    else
                    {
                        scoreAvailable[own.StageSeatId] = false;
                    }
                }
            }

            foreach (StageSeatScore seat in stageSeats)
            {
                // Reuse ScoreDifference as the stage score field for backwards
                // compatibility. It now contains the player's accumulated final
                // scores, not a plus/minus margin.
                seat.ScoreDifference = scoreAvailable[seat.SeatId]
                    ? (int?)accumulatedScores[seat.SeatId]
                    : null;

                int buchholz = 0;
                foreach (int opponentSeatId in opponents[seat.SeatId])
                {
                    StageSeatScore opponent;
                    if (bySeat.TryGetValue(opponentSeatId, out opponent))
                    {
                        buchholz += opponent.Wins;
                    }
                }
                seat.Buchholz = buchholz;
            }

            return stageSeats;
        }

        private static bool TryRankSwissStage(
            List<StageSeatScore> standings,
            List<ChildSeatResult> childResults,
            List<SwissMatchInfo> swissMatches,
            bool higherScoreIsBetter,
            out List<StageSeatScore> ranked,
            out string unresolvedReason)
        {
            ranked = new List<StageSeatScore>();
            unresolvedReason = null;

            bool scoreDifferenceAvailable =
                standings.All(x => x.ScoreDifference.HasValue);

            List<StageSeatScore> initial;
            if (scoreDifferenceAvailable)
            {
                IOrderedEnumerable<StageSeatScore> baseOrder = standings
                    .OrderByDescending(x => x.Wins)
                    .ThenByDescending(x => x.Buchholz);

                initial = higherScoreIsBetter
                    ? baseOrder.ThenByDescending(x => x.ScoreDifference.Value).ToList()
                    : baseOrder.ThenBy(x => x.ScoreDifference.Value).ToList();
            }
            else
            {
                initial = standings
                    .OrderByDescending(x => x.Wins)
                    .ThenByDescending(x => x.Buchholz)
                    .ToList();
            }

            int index = 0;
            while (index < initial.Count)
            {
                StageSeatScore first = initial[index];

                List<StageSeatScore> tied = initial
                    .Skip(index)
                    .TakeWhile(x =>
                        x.Wins == first.Wins &&
                        x.Buchholz == first.Buchholz &&
                        (!scoreDifferenceAvailable ||
                         x.ScoreDifference == first.ScoreDifference))
                    .ToList();

                if (tied.Count == 1)
                {
                    ranked.Add(tied[0]);
                    index++;
                    continue;
                }

                HashSet<int> tiedSeatIds =
                    new HashSet<int>(tied.Select(x => x.SeatId));

                foreach (StageSeatScore player in tied)
                {
                    player.HeadToHeadWins = 0;

                    foreach (SwissMatchInfo match in swissMatches)
                    {
                        List<ChildSeatResult> seats = childResults
                            .Where(x =>
                                x.MatchId == match.MatchId &&
                                x.PlayerId > 0)
                            .ToList();

                        if (seats.Count != 2)
                        {
                            continue;
                        }

                        bool containsPlayer =
                            seats.Any(x => x.StageSeatId == player.SeatId);

                        bool containsOtherTied =
                            seats.Any(x =>
                                x.StageSeatId != player.SeatId &&
                                tiedSeatIds.Contains(x.StageSeatId));

                        if (containsPlayer &&
                            containsOtherTied &&
                            seats.Any(x =>
                                x.StageSeatId == player.SeatId &&
                                x.ResultMatchPlace == 1))
                        {
                            player.HeadToHeadWins++;
                        }
                    }
                }

                List<StageSeatScore> tieOrdered = tied
                    .OrderByDescending(x => x.HeadToHeadWins)
                    .ToList();

                bool stillTied = tieOrdered
                    .GroupBy(x => x.HeadToHeadWins)
                    .Any(g => g.Count() > 1);

                if (stillTied)
                {
                    unresolvedReason = scoreDifferenceAvailable
                        ? "Players are still tied on wins, Buchholz, accumulated score and head-to-head. Play an extra deciding match before advancing them."
                        : "Players are still tied on wins, Buchholz and head-to-head. Enter scores for every match or play an extra deciding match.";
                    return false;
                }

                ranked.AddRange(tieOrdered);
                index += tied.Count;
            }

            return true;
        }

        private static string SwissPairKey(int seatA, int seatB)
        {
            int low = Math.Min(seatA, seatB);
            int high = Math.Max(seatA, seatB);
            return low.ToString() + ":" + high.ToString();
        }

        private static HashSet<string> GetPreviousSwissPairs(
            List<ChildSeatResult> childResults,
            List<SwissMatchInfo> swissMatches)
        {
            HashSet<string> pairs = new HashSet<string>();

            foreach (SwissMatchInfo match in swissMatches)
            {
                List<ChildSeatResult> seats = childResults
                    .Where(x => x.MatchId == match.MatchId && x.PlayerId > 0)
                    .ToList();

                if (seats.Count == 2)
                {
                    pairs.Add(SwissPairKey(
                        seats[0].StageSeatId,
                        seats[1].StageSeatId));
                }
            }

            return pairs;
        }

        private static bool TryPairSwissPlayersRecursive(
            List<StageSeatScore> remaining,
            HashSet<string> previousPairs,
            bool allowRematches,
            List<SwissPair> result)
        {
            if (remaining.Count == 0)
            {
                return true;
            }

            StageSeatScore first = remaining[0];

            List<StageSeatScore> candidates = remaining
                .Skip(1)
                .OrderBy(x => Math.Abs(x.Wins - first.Wins))
                .ThenBy(x => Math.Abs(x.Buchholz - first.Buchholz))
                .ThenBy(x => Math.Abs((x.ScoreDifference ?? 0) - (first.ScoreDifference ?? 0)))
                .ThenBy(x => x.SeatId)
                .ToList();

            foreach (StageSeatScore candidate in candidates)
            {
                bool isRematch = previousPairs.Contains(
                    SwissPairKey(first.SeatId, candidate.SeatId));

                if (isRematch && !allowRematches)
                {
                    continue;
                }

                List<StageSeatScore> next = remaining
                    .Where(x =>
                        x.SeatId != first.SeatId &&
                        x.SeatId != candidate.SeatId)
                    .ToList();

                result.Add(new SwissPair
                {
                    First = first,
                    Second = candidate
                });

                if (TryPairSwissPlayersRecursive(
                    next,
                    previousPairs,
                    allowRematches,
                    result))
                {
                    return true;
                }

                result.RemoveAt(result.Count - 1);
            }

            return false;
        }

        private static List<SwissPair> BuildSwissPairings(
            List<StageSeatScore> standings,
            HashSet<string> previousPairs,
            bool higherScoreIsBetter,
            out StageSeatScore? byePlayer)
        {
            IOrderedEnumerable<StageSeatScore> baseOrder = standings
                .OrderByDescending(x => x.Wins)
                .ThenByDescending(x => x.Buchholz);

            List<StageSeatScore> ordered = (higherScoreIsBetter
                    ? baseOrder.ThenByDescending(x => x.ScoreDifference ?? Int32.MinValue)
                    : baseOrder.ThenBy(x => x.ScoreDifference ?? Int32.MaxValue))
                .ThenBy(x => x.SeatId)
                .ToList();

            byePlayer = null;

            if (ordered.Count % 2 != 0)
            {
                StageSeatScore? selectedBye = ordered
                    .AsEnumerable()
                    .Reverse()
                    .FirstOrDefault(x => !x.HadBye);

                if (selectedBye == null)
                {
                    selectedBye = ordered.Last();
                }

                byePlayer = selectedBye;
                int byeSeatId = selectedBye.SeatId;
                ordered.RemoveAll(x => x.SeatId == byeSeatId);
            }

            List<SwissPair> pairings = new List<SwissPair>();

            if (!TryPairSwissPlayersRecursive(
                ordered,
                previousPairs,
                false,
                pairings))
            {
                pairings.Clear();

                if (!TryPairSwissPlayersRecursive(
                    ordered,
                    previousPairs,
                    true,
                    pairings))
                {
                    throw new InvalidOperationException(
                        "Swiss pairings could not be generated.");
                }
            }

            return pairings;
        }

        private static int InsertSwissMatch(
            SqlConnection conn,
            SqlTransaction transaction,
            int stageMatchId,
            int matchRulesId,
            string matchName)
        {
            using (SqlCommand cmd = new SqlCommand(@"
INSERT INTO [Match]
(
    ParentMatchId,
    MatchRulesId,
    IndividualMatch,
    [Name]
)
VALUES
(
    @ParentMatchId,
    @MatchRulesId,
    1,
    @Name
);

SELECT CAST(SCOPE_IDENTITY() AS INT);", conn, transaction))
            {
                cmd.Parameters.Add("@ParentMatchId", SqlDbType.Int).Value =
                    stageMatchId;
                cmd.Parameters.Add("@MatchRulesId", SqlDbType.Int).Value =
                    matchRulesId;
                cmd.Parameters.Add("@Name", SqlDbType.NVarChar, 255).Value =
                    matchName;

                return Convert.ToInt32(cmd.ExecuteScalar());
            }
        }

        private static int InsertSwissSeat(
            SqlConnection conn,
            SqlTransaction transaction,
            int parentSeatId,
            int playerId,
            int matchId,
            int? resultPlace,
            int? resultPoints)
        {
            using (SqlCommand cmd = new SqlCommand(@"
INSERT INTO Seat
(
    ParentSeatId,
    PlayerId,
    MatchId,
    ResultMatchPlace,
    ResultPoints
)
VALUES
(
    @ParentSeatId,
    @PlayerId,
    @MatchId,
    @ResultMatchPlace,
    @ResultPoints
);

SELECT CAST(SCOPE_IDENTITY() AS INT);", conn, transaction))
            {
                cmd.Parameters.Add("@ParentSeatId", SqlDbType.Int).Value =
                    parentSeatId;
                cmd.Parameters.Add("@PlayerId", SqlDbType.Int).Value =
                    playerId;
                cmd.Parameters.Add("@MatchId", SqlDbType.Int).Value =
                    matchId;

                SqlParameter place = cmd.Parameters.Add(
                    "@ResultMatchPlace",
                    SqlDbType.Int);
                place.Value = resultPlace.HasValue
                    ? (object)resultPlace.Value
                    : DBNull.Value;

                SqlParameter points = cmd.Parameters.Add(
                    "@ResultPoints",
                    SqlDbType.Int);
                points.Value = resultPoints.HasValue
                    ? (object)resultPoints.Value
                    : DBNull.Value;

                return Convert.ToInt32(cmd.ExecuteScalar());
            }
        }

        private static int CreateNextSwissRound(
            SqlConnection conn,
            SqlTransaction transaction,
            int stageMatchId,
            int nextRound,
            List<StageSeatScore> standings,
            List<ChildSeatResult> childResults,
            List<SwissMatchInfo> swissMatches,
            int? playTo,
            bool higherScoreIsBetter)
        {
            if (swissMatches.Any(x => x.Round == nextRound))
            {
                return 0;
            }

            int matchRulesId = swissMatches
                .Select(x => x.MatchRulesId)
                .FirstOrDefault();

            if (matchRulesId <= 0)
            {
                throw new InvalidOperationException(
                    "The Swiss stage does not have match rules.");
            }

            HashSet<string> previousPairs =
                GetPreviousSwissPairs(childResults, swissMatches);

            StageSeatScore? byePlayer;
            List<SwissPair> pairings = BuildSwissPairings(
                standings,
                previousPairs,
                higherScoreIsBetter,
                out byePlayer);

            string roundStageName =
                GetSwissRoundStageName(conn, transaction, stageMatchId);

            string poolName =
                GetMatchName(conn, transaction, stageMatchId);

            int matchNumber = 1;

            foreach (SwissPair pairing in pairings)
            {
                string name =
                    "runde: " + roundStageName +
                    " " + poolName +
                    " Swiss round " + nextRound +
                    " Match " + matchNumber;

                int matchId = InsertSwissMatch(
                    conn,
                    transaction,
                    stageMatchId,
                    matchRulesId,
                    name);

                InsertSwissSeat(
                    conn,
                    transaction,
                    pairing.First.SeatId,
                    pairing.First.PlayerId,
                    matchId,
                    null,
                    null);

                InsertSwissSeat(
                    conn,
                    transaction,
                    pairing.Second.SeatId,
                    pairing.Second.PlayerId,
                    matchId,
                    null,
                    null);

                matchNumber++;
            }

            if (byePlayer != null)
            {
                string byeName =
                    "runde: " + roundStageName +
                    " " + poolName +
                    " Swiss round " + nextRound +
                    " BYE";

                int byeMatchId = InsertSwissMatch(
                    conn,
                    transaction,
                    stageMatchId,
                    matchRulesId,
                    byeName);

                InsertSwissSeat(
                    conn,
                    transaction,
                    byePlayer.SeatId,
                    byePlayer.PlayerId,
                    byeMatchId,
                    1,
                    playTo ?? 0);
            }

            return pairings.Count + (byePlayer == null ? 0 : 1);
        }

        private static StageAdvanceResult RecalculateSwissStage(
            SqlConnection conn,
            SqlTransaction transaction,
            int stageMatchId,
            string stageName)
        {
            List<StageSeatScore> stageSeats =
                GetStageSeats(conn, transaction, stageMatchId);

            List<SwissMatchInfo> swissMatches =
                GetSwissMatches(conn, transaction, stageMatchId);

            List<ChildSeatResult> childResults =
                GetChildResults(conn, transaction, stageMatchId);

            StageAdvanceResult response = new StageAdvanceResult
            {
                StageMatchId = stageMatchId,
                StageName = stageName,
                StageComplete = false,
                PlacementResolved = false
            };

            if (stageSeats.Count < 2 || swissMatches.Count == 0)
            {
                ClearStageOutcomeAndDestinations(
                    conn,
                    transaction,
                    stageMatchId,
                    false,
                    new HashSet<int>());

                response.Message =
                    "Result saved. The Swiss stage is still waiting for players or pairings.";
                return response;
            }

            int currentRound = swissMatches.Max(x => x.Round);
            int totalRounds = GetSwissTotalRounds(
                conn,
                transaction,
                stageMatchId,
                stageSeats.Count);

            List<SwissMatchInfo> currentMatches = swissMatches
                .Where(x => x.Round == currentRound)
                .ToList();

            foreach (SwissMatchInfo match in currentMatches)
            {
                List<ChildSeatResult> seats = childResults
                    .Where(x =>
                        x.MatchId == match.MatchId &&
                        x.PlayerId > 0)
                    .ToList();

                bool complete =
                    seats.Count == 1
                        ? seats[0].ResultMatchPlace == 1
                        : seats.Count >= 2 &&
                          seats.All(x => x.ResultMatchPlace.HasValue);

                if (!complete)
                {
                    ClearStageOutcomeAndDestinations(
                        conn,
                        transaction,
                        stageMatchId,
                        false,
                        new HashSet<int>());

                    response.Message =
                        "Swiss round " + currentRound +
                        " is not complete yet. The next pairings will be created when every match in this round has a result.";
                    return response;
                }
            }

            int? playFrom = GetPlayFrom(
                conn,
                transaction,
                stageMatchId);

            int? playTo = GetPlayTo(
                conn,
                transaction,
                stageMatchId);

            bool higherScoreIsBetter = IsHigherScoreBetter(playFrom, playTo);

            List<StageSeatScore> standings = BuildSwissStandings(
                stageSeats,
                childResults,
                swissMatches,
                playTo);

            if (currentRound < totalRounds)
            {
                int nextRound = currentRound + 1;

                int created = CreateNextSwissRound(
                    conn,
                    transaction,
                    stageMatchId,
                    nextRound,
                    standings,
                    childResults,
                    swissMatches,
                    playTo,
                    higherScoreIsBetter);

                response.Message =
                    "Swiss round " + currentRound +
                    " complete. Swiss round " + nextRound +
                    " pairings were created" +
                    (created > 0
                        ? " (" + created + " match" +
                          (created == 1 ? "" : "es") + ")."
                        : ".");

                return response;
            }

            response.StageComplete = true;

            List<StageSeatScore> ranked;
            string unresolvedReason;

            if (!TryRankSwissStage(
                standings,
                childResults,
                swissMatches,
                higherScoreIsBetter,
                out ranked,
                out unresolvedReason))
            {
                ClearStageOutcomeAndDestinations(
                    conn,
                    transaction,
                    stageMatchId,
                    false,
                    new HashSet<int>());

                response.Message =
                    "All Swiss rounds are complete, but the final placement is tied. " +
                    unresolvedReason;
                return response;
            }

            response.PlacementResolved = true;

            SaveStagePlacements(
                conn,
                transaction,
                ranked);

            response.AdvancedPlayers =
                MovePlayersToDestinationSeats(
                    conn,
                    transaction,
                    stageMatchId,
                    ranked);

            response.Message =
                "Swiss stage complete after " + totalRounds +
                " rounds. Final placements were saved" +
                (response.AdvancedPlayers.Count > 0
                    ? " and " + response.AdvancedPlayers.Count +
                      " player" +
                      (response.AdvancedPlayers.Count == 1 ? " was" : "s were") +
                      " moved to the configured next stage."
                    : ".");

            return response;
        }

        private static void DeleteSwissRoundsAfter(
            SqlConnection conn,
            SqlTransaction transaction,
            int stageMatchId,
            int round)
        {
            List<SwissMatchInfo> laterMatches = GetSwissMatches(
                conn,
                transaction,
                stageMatchId)
                .Where(x => x.Round > round)
                .OrderByDescending(x => x.Round)
                .ThenByDescending(x => x.MatchId)
                .ToList();

            foreach (SwissMatchInfo match in laterMatches)
            {
                UndoMmrForMatch(
                    conn,
                    transaction,
                    match.MatchId);

                using (SqlCommand cmd = new SqlCommand(@"
DELETE FROM Seat
WHERE MatchId = @MatchId;

DELETE FROM [Match]
WHERE Id = @MatchId;", conn, transaction))
                {
                    cmd.Parameters.Add("@MatchId", SqlDbType.Int).Value =
                        match.MatchId;
                    cmd.ExecuteNonQuery();
                }
            }
        }

        private static void RestoreSwissByeResults(
            SqlConnection conn,
            SqlTransaction transaction,
            int stageMatchId,
            int round)
        {
            foreach (SwissMatchInfo match in GetSwissMatches(
                conn,
                transaction,
                stageMatchId).Where(x => x.Round == round))
            {
                int seatCount;

                using (SqlCommand cmd = new SqlCommand(@"
SELECT COUNT(1)
FROM Seat
WHERE MatchId = @MatchId
  AND PlayerId IS NOT NULL;", conn, transaction))
                {
                    cmd.Parameters.Add("@MatchId", SqlDbType.Int).Value =
                        match.MatchId;
                    seatCount = Convert.ToInt32(cmd.ExecuteScalar());
                }

                if (seatCount != 1)
                {
                    continue;
                }

                int? playTo = GetPlayTo(
                    conn,
                    transaction,
                    stageMatchId);

                using (SqlCommand cmd = new SqlCommand(@"
UPDATE Seat
SET ResultMatchPlace = 1,
    ResultPoints = @ResultPoints
WHERE MatchId = @MatchId
  AND PlayerId IS NOT NULL;", conn, transaction))
                {
                    cmd.Parameters.Add("@MatchId", SqlDbType.Int).Value =
                        match.MatchId;
                    cmd.Parameters.Add("@ResultPoints", SqlDbType.Int).Value =
                        playTo ?? 0;
                    cmd.ExecuteNonQuery();
                }
            }
        }

        private static void InvalidateFutureSwissRounds(
            SqlConnection conn,
            SqlTransaction transaction,
            int matchId)
        {
            int? stageMatchId =
                GetParentStageMatchId(conn, transaction, matchId);

            if (!stageMatchId.HasValue ||
                !IsSwissStage(conn, transaction, stageMatchId.Value))
            {
                return;
            }

            int round = GetSwissRoundForMatch(
                conn,
                transaction,
                matchId);

            if (round <= 0)
            {
                return;
            }

            bool hasLaterRounds = GetSwissMatches(
                conn,
                transaction,
                stageMatchId.Value)
                .Any(x => x.Round > round);

            if (!hasLaterRounds)
            {
                return;
            }

            ClearStageOutcomeAndDestinations(
                conn,
                transaction,
                stageMatchId.Value,
                false,
                new HashSet<int>());

            DeleteSwissRoundsAfter(
                conn,
                transaction,
                stageMatchId.Value,
                round);
        }

        private static bool TryRankStage(
            List<StageSeatScore> stageSeats,
            List<ChildSeatResult> childResults,
            List<int> childMatchIds,
            int? playFrom,
            int? playTo,
            out List<StageSeatScore> ranked,
            out string unresolvedReason)
        {
            ranked = new List<StageSeatScore>();
            unresolvedReason = null;

            // If the whole stage is one multi-player match, the entered place is the stage place.
            if (childMatchIds.Count == 1)
            {
                int onlyMatchId = childMatchIds[0];
                List<ChildSeatResult> directResults = childResults
                    .Where(x => x.MatchId == onlyMatchId && x.PlayerId > 0)
                    .ToList();

                if (directResults.Count == stageSeats.Count && directResults.All(x => x.ResultMatchPlace.HasValue))
                {
                    foreach (StageSeatScore stageSeat in stageSeats)
                    {
                        ChildSeatResult direct = directResults.FirstOrDefault(x => x.StageSeatId == stageSeat.SeatId);
                        if (direct == null)
                        {
                            unresolvedReason = "A stage seat could not be matched to the playable match.";
                            return false;
                        }

                        stageSeat.DirectPlace = direct.ResultMatchPlace;
                        stageSeat.DirectPoints = direct.ResultPoints;
                    }

                    if (stageSeats.Select(x => x.DirectPlace.Value).Distinct().Count() != stageSeats.Count)
                    {
                        unresolvedReason = "Each player must have a unique place.";
                        return false;
                    }

                    ranked = stageSeats.OrderBy(x => x.DirectPlace.Value).ToList();
                    return true;
                }
            }

            foreach (StageSeatScore stageSeat in stageSeats)
            {
                List<ChildSeatResult> playerResults = childResults
                    .Where(x => x.StageSeatId == stageSeat.SeatId && x.PlayerId == stageSeat.PlayerId)
                    .ToList();

                stageSeat.Wins = playerResults.Count(x => x.ResultMatchPlace == 1);

                // The pool Score is the sum of the player's actual final scores.
                // Example with 70 -> 0: results 60, 20 and 0 give Score = 80.
                // When counting down (70 -> 0), lower accumulated score is better.
                // When counting up (0 -> 70), higher accumulated score is better.
                bool completeScores = playerResults.All(x => x.ResultPoints.HasValue);
                stageSeat.ScoreDifference = completeScores
                    ? (int?)playerResults.Sum(x => x.ResultPoints.Value)
                    : null;
            }

            bool scoreDifferenceAvailable = stageSeats.All(x => x.ScoreDifference.HasValue);

            bool higherScoreIsBetter = IsHigherScoreBetter(playFrom, playTo);

            List<StageSeatScore> initial;
            if (scoreDifferenceAvailable)
            {
                IOrderedEnumerable<StageSeatScore> baseOrder =
                    stageSeats.OrderByDescending(x => x.Wins);

                initial = higherScoreIsBetter
                    ? baseOrder.ThenByDescending(x => x.ScoreDifference.Value).ToList()
                    : baseOrder.ThenBy(x => x.ScoreDifference.Value).ToList();
            }
            else
            {
                initial = stageSeats
                    .OrderByDescending(x => x.Wins)
                    .ToList();
            }

            List<StageSeatScore> finalRanking = new List<StageSeatScore>();
            int index = 0;
            while (index < initial.Count)
            {
                StageSeatScore first = initial[index];
                List<StageSeatScore> tied = initial
                    .Skip(index)
                    .TakeWhile(x =>
                        x.Wins == first.Wins &&
                        (!scoreDifferenceAvailable || x.ScoreDifference == first.ScoreDifference))
                    .ToList();

                if (tied.Count == 1)
                {
                    finalRanking.Add(tied[0]);
                    index++;
                    continue;
                }

                HashSet<int> tiedSeatIds = new HashSet<int>(tied.Select(x => x.SeatId));
                foreach (StageSeatScore player in tied)
                {
                    HashSet<int> matchesAgainstTiedPlayers = new HashSet<int>();

                    foreach (int matchId in childMatchIds)
                    {
                        List<ChildSeatResult> matchSeats = childResults
                            .Where(x => x.MatchId == matchId && x.PlayerId > 0)
                            .ToList();

                        bool containsPlayer = matchSeats.Any(x => x.StageSeatId == player.SeatId);
                        bool containsAnotherTiedPlayer = matchSeats.Any(x =>
                            x.StageSeatId != player.SeatId && tiedSeatIds.Contains(x.StageSeatId));

                        if (containsPlayer && containsAnotherTiedPlayer)
                        {
                            matchesAgainstTiedPlayers.Add(matchId);
                        }
                    }

                    player.HeadToHeadWins = childResults.Count(x =>
                        x.StageSeatId == player.SeatId &&
                        x.ResultMatchPlace == 1 &&
                        matchesAgainstTiedPlayers.Contains(x.MatchId));
                }

                List<StageSeatScore> tieOrdered = tied
                    .OrderByDescending(x => x.HeadToHeadWins)
                    .ToList();

                bool stillTied = tieOrdered
                    .GroupBy(x => x.HeadToHeadWins)
                    .Any(g => g.Count() > 1);

                if (stillTied)
                {
                    unresolvedReason = scoreDifferenceAvailable
                        ? "The players are still tied on wins, accumulated score and head-to-head results. Play an extra deciding match before advancing them."
                        : "Scores are missing, so accumulated score cannot break the tie. Enter the final score for every match or play an extra deciding match.";
                    return false;
                }

                finalRanking.AddRange(tieOrdered);
                index += tied.Count;
            }

            ranked = finalRanking;
            return true;
        }

        private static void SaveStagePlacements(
            SqlConnection conn,
            SqlTransaction transaction,
            List<StageSeatScore> ranked)
        {
            const string sql = @"
UPDATE Seat
SET ResultMatchPlace = @Place,
    ResultPoints = @Points
WHERE Id = @SeatId;";

            for (int i = 0; i < ranked.Count; i++)
            {
                StageSeatScore player = ranked[i];
                int place = player.DirectPlace ?? (i + 1);
                int points = player.DirectPoints ?? player.ScoreDifference ?? 0;

                using (SqlCommand cmd = new SqlCommand(sql, conn, transaction))
                {
                    cmd.Parameters.Add("@SeatId", SqlDbType.Int).Value = player.SeatId;
                    cmd.Parameters.Add("@Place", SqlDbType.Int).Value = place;
                    cmd.Parameters.Add("@Points", SqlDbType.Int).Value = points;
                    cmd.ExecuteNonQuery();
                }
            }
        }

        private static List<AdvancedPlayerDetails> MovePlayersToDestinationSeats(
            SqlConnection conn,
            SqlTransaction transaction,
            int sourceStageMatchId,
            List<StageSeatScore> ranked)
        {
            List<AdvancedPlayerDetails> advanced = new List<AdvancedPlayerDetails>();
            HashSet<int> invalidatedDestinationStages = new HashSet<int>();

            for (int i = 0; i < ranked.Count; i++)
            {
                StageSeatScore player = ranked[i];
                int place = player.DirectPlace ?? (i + 1);
                List<DestinationSeat> destinations = GetDestinationSeats(
                    conn,
                    transaction,
                    sourceStageMatchId,
                    place);

                foreach (DestinationSeat destination in destinations)
                {
                    if (!destination.PlayerId.HasValue || destination.PlayerId.Value != player.PlayerId)
                    {
                        if (!invalidatedDestinationStages.Contains(destination.MatchId))
                        {
                            ClearStageOutcomeAndDestinations(
                                conn,
                                transaction,
                                destination.MatchId,
                                true,
                                new HashSet<int>());
                            invalidatedDestinationStages.Add(destination.MatchId);
                        }

                        SetPlayerOnSeatAndChildren(
                            conn,
                            transaction,
                            destination.SeatId,
                            player.PlayerId);

                        if (IsSwissStage(conn, transaction, destination.MatchId))
                        {
                            RestoreSwissByeResults(
                                conn,
                                transaction,
                                destination.MatchId,
                                1);
                        }
                    }

                    advanced.Add(new AdvancedPlayerDetails
                    {
                        PlayerId = player.PlayerId,
                        PlayerName = player.PlayerName,
                        Place = place,
                        DestinationSeatId = destination.SeatId,
                        DestinationMatchId = destination.MatchId,
                        DestinationMatchName = destination.MatchName
                    });
                }
            }

            return advanced;
        }

        private static void ClearStageOutcomeAndDestinations(
            SqlConnection conn,
            SqlTransaction transaction,
            int stageMatchId,
            bool clearChildMatchResults,
            HashSet<int> visitedStages)
        {
            if (!visitedStages.Add(stageMatchId))
            {
                return;
            }

            using (SqlCommand cmd = new SqlCommand(@"
UPDATE Seat
SET ResultMatchPlace = NULL,
    ResultPoints = NULL
WHERE MatchId = @StageMatchId;", conn, transaction))
            {
                cmd.Parameters.Add("@StageMatchId", SqlDbType.Int).Value = stageMatchId;
                cmd.ExecuteNonQuery();
            }

            if (clearChildMatchResults)
            {
                UndoMmrForStageChildMatches(conn, transaction, stageMatchId);

                bool swissStage = IsSwissStage(conn, transaction, stageMatchId);
                if (swissStage)
                {
                    // Later Swiss rounds depend on earlier standings. If this stage is
                    // invalidated by an upstream change, keep only round 1 and let the
                    // following rounds be generated again from the new results.
                    DeleteSwissRoundsAfter(conn, transaction, stageMatchId, 1);
                }

                using (SqlCommand cmd = new SqlCommand(@"
UPDATE S
SET S.ResultMatchPlace = NULL,
    S.ResultPoints = NULL
FROM Seat S
INNER JOIN [Match] M ON M.Id = S.MatchId
WHERE M.ParentMatchId = @StageMatchId
  AND M.IndividualMatch = 1;", conn, transaction))
                {
                    cmd.Parameters.Add("@StageMatchId", SqlDbType.Int).Value = stageMatchId;
                    cmd.ExecuteNonQuery();
                }

                if (swissStage)
                {
                    // A Swiss bye is an automatic win and must remain complete after
                    // results are reset.
                    RestoreSwissByeResults(conn, transaction, stageMatchId, 1);
                }
            }

            List<DestinationSeat> downstream = GetAllDestinationSeats(conn, transaction, stageMatchId);
            foreach (int nextStageId in downstream.Select(x => x.MatchId).Distinct())
            {
                ClearStageOutcomeAndDestinations(
                    conn,
                    transaction,
                    nextStageId,
                    true,
                    visitedStages);
            }

            foreach (DestinationSeat destination in downstream)
            {
                ClearPlayerFromSeatAndChildren(conn, transaction, destination.SeatId);
            }
        }

        private static void SetPlayerOnSeatAndChildren(
            SqlConnection conn,
            SqlTransaction transaction,
            int seatId,
            int playerId)
        {
            using (SqlCommand cmd = new SqlCommand(@"
UPDATE Seat
SET PlayerId = @PlayerId,
    ResultMatchPlace = NULL,
    ResultPoints = NULL
WHERE Id = @SeatId
   OR ParentSeatId = @SeatId;", conn, transaction))
            {
                cmd.Parameters.Add("@SeatId", SqlDbType.Int).Value = seatId;
                cmd.Parameters.Add("@PlayerId", SqlDbType.Int).Value = playerId;
                cmd.ExecuteNonQuery();
            }
        }

        private static void ClearPlayerFromSeatAndChildren(
            SqlConnection conn,
            SqlTransaction transaction,
            int seatId)
        {
            using (SqlCommand cmd = new SqlCommand(@"
UPDATE Seat
SET PlayerId = NULL,
    ResultMatchPlace = NULL,
    ResultPoints = NULL
WHERE Id = @SeatId
   OR ParentSeatId = @SeatId;", conn, transaction))
            {
                cmd.Parameters.Add("@SeatId", SqlDbType.Int).Value = seatId;
                cmd.ExecuteNonQuery();
            }
        }

        private static int? GetParentStageMatchId(
            SqlConnection conn,
            SqlTransaction transaction,
            int matchId)
        {
            using (SqlCommand cmd = new SqlCommand(@"
SELECT ParentMatchId
FROM [Match]
WHERE Id = @MatchId
  AND IndividualMatch = 1;", conn, transaction))
            {
                cmd.Parameters.Add("@MatchId", SqlDbType.Int).Value = matchId;
                object value = cmd.ExecuteScalar();
                return value == null || value == DBNull.Value
                    ? (int?)null
                    : Convert.ToInt32(value);
            }
        }

        private static string GetMatchName(
            SqlConnection conn,
            SqlTransaction transaction,
            int matchId)
        {
            using (SqlCommand cmd = new SqlCommand("SELECT Name FROM [Match] WHERE Id = @MatchId;", conn, transaction))
            {
                cmd.Parameters.Add("@MatchId", SqlDbType.Int).Value = matchId;
                object value = cmd.ExecuteScalar();
                return value == null || value == DBNull.Value ? null : Convert.ToString(value);
            }
        }

        private static List<StageSeatScore> GetStageSeats(
            SqlConnection conn,
            SqlTransaction transaction,
            int stageMatchId)
        {
            List<StageSeatScore> result = new List<StageSeatScore>();
            using (SqlCommand cmd = new SqlCommand(@"
SELECT S.Id, S.PlayerId, P.Name AS PlayerName
FROM Seat S
LEFT JOIN Player P ON P.Id = S.PlayerId
WHERE S.MatchId = @StageMatchId
  AND S.PlayerId IS NOT NULL
ORDER BY S.Id;", conn, transaction))
            {
                cmd.Parameters.Add("@StageMatchId", SqlDbType.Int).Value = stageMatchId;
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        result.Add(new StageSeatScore
                        {
                            SeatId = Convert.ToInt32(reader["Id"]),
                            PlayerId = Convert.ToInt32(reader["PlayerId"]),
                            PlayerName = reader["PlayerName"] == DBNull.Value ? null : Convert.ToString(reader["PlayerName"])
                        });
                    }
                }
            }
            return result;
        }


        private static int? GetPlayFrom(
            SqlConnection conn,
            SqlTransaction transaction,
            int stageMatchId)
        {
            using (SqlCommand cmd = new SqlCommand(@"
SELECT TOP 1 MR.PlayFrom
FROM [Match] M
INNER JOIN MatchRules MR ON MR.Id = M.MatchRulesId
WHERE (M.ParentMatchId = @StageMatchId AND M.IndividualMatch = 1)
   OR M.Id = @StageMatchId
ORDER BY CASE WHEN M.ParentMatchId = @StageMatchId THEN 0 ELSE 1 END, M.Id;", conn, transaction))
            {
                cmd.Parameters.Add("@StageMatchId", SqlDbType.Int).Value = stageMatchId;
                object value = cmd.ExecuteScalar();
                if (value == null || value == DBNull.Value)
                {
                    return null;
                }

                return Convert.ToInt32(value);
            }
        }

        private static bool IsHigherScoreBetter(int? playFrom, int? playTo)
        {
            if (playFrom.HasValue && playTo.HasValue)
            {
                return playTo.Value > playFrom.Value;
            }

            // If the rule is incomplete, preserve the traditional high-score sort.
            return true;
        }

        private static int? GetPlayTo(
            SqlConnection conn,
            SqlTransaction transaction,
            int stageMatchId)
        {
            // Prefer the rules on a playable child match. If none are found,
            // fall back to rules attached to the stage itself.
            using (SqlCommand cmd = new SqlCommand(@"
SELECT TOP 1 MR.PlayTo
FROM [Match] M
INNER JOIN MatchRules MR ON MR.Id = M.MatchRulesId
WHERE (M.ParentMatchId = @StageMatchId AND M.IndividualMatch = 1)
   OR M.Id = @StageMatchId
ORDER BY CASE WHEN M.ParentMatchId = @StageMatchId THEN 0 ELSE 1 END, M.Id;", conn, transaction))
            {
                cmd.Parameters.Add("@StageMatchId", SqlDbType.Int).Value = stageMatchId;
                object value = cmd.ExecuteScalar();
                if (value == null || value == DBNull.Value)
                {
                    return null;
                }

                return Convert.ToInt32(value);
            }
        }

        private static List<int> GetChildMatchIds(
            SqlConnection conn,
            SqlTransaction transaction,
            int stageMatchId)
        {
            List<int> result = new List<int>();
            using (SqlCommand cmd = new SqlCommand(@"
SELECT Id
FROM [Match]
WHERE ParentMatchId = @StageMatchId
  AND IndividualMatch = 1
ORDER BY Id;", conn, transaction))
            {
                cmd.Parameters.Add("@StageMatchId", SqlDbType.Int).Value = stageMatchId;
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        result.Add(Convert.ToInt32(reader["Id"]));
                    }
                }
            }
            return result;
        }

        private static List<ChildSeatResult> GetChildResults(
            SqlConnection conn,
            SqlTransaction transaction,
            int stageMatchId)
        {
            List<ChildSeatResult> result = new List<ChildSeatResult>();
            using (SqlCommand cmd = new SqlCommand(@"
SELECT
    S.MatchId,
    S.ParentSeatId,
    S.PlayerId,
    S.ResultMatchPlace,
    S.ResultPoints
FROM Seat S
INNER JOIN [Match] M ON M.Id = S.MatchId
WHERE M.ParentMatchId = @StageMatchId
  AND M.IndividualMatch = 1
ORDER BY S.MatchId, S.Id;", conn, transaction))
            {
                cmd.Parameters.Add("@StageMatchId", SqlDbType.Int).Value = stageMatchId;
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        if (reader["ParentSeatId"] == DBNull.Value || reader["PlayerId"] == DBNull.Value)
                        {
                            continue;
                        }

                        result.Add(new ChildSeatResult
                        {
                            MatchId = Convert.ToInt32(reader["MatchId"]),
                            StageSeatId = Convert.ToInt32(reader["ParentSeatId"]),
                            PlayerId = Convert.ToInt32(reader["PlayerId"]),
                            ResultMatchPlace = ToNullableInt(reader["ResultMatchPlace"]),
                            ResultPoints = ToNullableInt(reader["ResultPoints"])
                        });
                    }
                }
            }
            return result;
        }

        private static List<int> GetStageSourcePoolIds(
            SqlConnection conn,
            SqlTransaction transaction,
            int sourceStageMatchId)
        {
            List<int> result = new List<int>();
            using (SqlCommand cmd = new SqlCommand(@"
SELECT M.Id
FROM [Match] M
WHERE M.ParentMatchId = @SourceStageMatchId
  AND ISNULL(M.IndividualMatch, 0) = 0
  AND (
        EXISTS (
            SELECT 1
            FROM [Match] C
            WHERE C.ParentMatchId = M.Id
              AND ISNULL(C.IndividualMatch, 0) = 1
        )
        OR EXISTS (
            SELECT 1
            FROM Seat S
            WHERE S.MatchId = M.Id
              AND S.PlayerId IS NOT NULL
        )
      )
ORDER BY M.Id;", conn, transaction))
            {
                cmd.Parameters.Add("@SourceStageMatchId", SqlDbType.Int).Value = sourceStageMatchId;
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        result.Add(Convert.ToInt32(reader["Id"]));
                    }
                }
            }
            return result;
        }

        private static List<StageManualRouteRecord> GetStageManualRouteRecords(
            SqlConnection conn,
            SqlTransaction transaction,
            int sourceStageMatchId)
        {
            List<StageManualRouteRecord> routes = new List<StageManualRouteRecord>();

            using (SqlCommand cmd = new SqlCommand(@"
SELECT
    R.Id AS SeatId,
    R.AutoSelectMatchId AS SourcePoolMatchId,
    SP.Name AS SourcePoolName,
    R.AutoSelectlPlace AS Place,
    R.MatchId AS DestinationPoolMatchId,
    DP.Name AS DestinationPoolName,
    DP.ParentMatchId AS TargetStageMatchId,
    TS.Name AS TargetStageName
FROM Seat R
INNER JOIN [Match] SP ON SP.Id = R.AutoSelectMatchId
INNER JOIN [Match] DP ON DP.Id = R.MatchId
LEFT JOIN [Match] TS ON TS.Id = DP.ParentMatchId
WHERE SP.ParentMatchId = @SourceStageMatchId
  AND ISNULL(SP.IndividualMatch, 0) = 0
  AND R.AutoSelectlPlace IS NOT NULL
  AND R.AutoSelectlPlace > 0
ORDER BY R.AutoSelectMatchId, R.AutoSelectlPlace, R.Id;", conn, transaction))
            {
                cmd.Parameters.Add("@SourceStageMatchId", SqlDbType.Int).Value = sourceStageMatchId;
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        int destinationPoolId = Convert.ToInt32(reader["DestinationPoolMatchId"]);
                        int? parentStageId = ToNullableInt(reader["TargetStageMatchId"]);
                        routes.Add(new StageManualRouteRecord
                        {
                            SeatId = Convert.ToInt32(reader["SeatId"]),
                            SourcePoolMatchId = Convert.ToInt32(reader["SourcePoolMatchId"]),
                            SourcePoolName = ToNullableString(reader["SourcePoolName"]),
                            Place = Convert.ToInt32(reader["Place"]),
                            TargetStageMatchId = parentStageId ?? destinationPoolId,
                            TargetStageName = parentStageId.HasValue
                                ? ToNullableString(reader["TargetStageName"])
                                : ToNullableString(reader["DestinationPoolName"]),
                            DestinationPoolMatchId = destinationPoolId,
                            DestinationPoolName = ToNullableString(reader["DestinationPoolName"])
                        });
                    }
                }
            }

            foreach (StageManualRouteRecord route in routes)
            {
                List<Tuple<int, string>> matchingPlayers = new List<Tuple<int, string>>();
                using (SqlCommand cmd = new SqlCommand(@"
SELECT S.PlayerId, P.Name AS PlayerName
FROM Seat S
LEFT JOIN Player P ON P.Id = S.PlayerId
WHERE S.MatchId = @SourcePoolMatchId
  AND S.ResultMatchPlace = @Place
  AND S.PlayerId IS NOT NULL
ORDER BY S.Id;", conn, transaction))
                {
                    cmd.Parameters.Add("@SourcePoolMatchId", SqlDbType.Int).Value = route.SourcePoolMatchId;
                    cmd.Parameters.Add("@Place", SqlDbType.Int).Value = route.Place;
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            int playerId = Convert.ToInt32(reader["PlayerId"]);
                            matchingPlayers.Add(Tuple.Create(
                                playerId,
                                reader["PlayerName"] == DBNull.Value
                                    ? "Player #" + playerId
                                    : Convert.ToString(reader["PlayerName"])));
                        }
                    }
                }

                // A unique placement must identify exactly one player. If two
                // players still share the same placement, the stage is not ready
                // for manual routing yet.
                if (matchingPlayers.Count == 1)
                {
                    route.PlayerId = matchingPlayers[0].Item1;
                    route.PlayerName = matchingPlayers[0].Item2;
                }
            }

            return routes;
        }

        private static List<StageManualCandidateSeat> GetStageManualCandidateSeats(
            SqlConnection conn,
            SqlTransaction transaction,
            int sourceStageMatchId)
        {
            List<StageManualRouteRecord> routes =
                GetStageManualRouteRecords(conn, transaction, sourceStageMatchId);
            List<StageManualCandidateSeat> result = new List<StageManualCandidateSeat>();

            foreach (int targetStageId in routes.Select(x => x.TargetStageMatchId).Distinct())
            {
                using (SqlCommand cmd = new SqlCommand(@"
SELECT
    S.Id AS SeatId,
    S.MatchId,
    M.ParentMatchId AS TargetStageMatchId,
    S.AutoSelectMatchId,
    S.AutoSelectlPlace,
    S.PlayerId
FROM Seat S
INNER JOIN [Match] M ON M.Id = S.MatchId
LEFT JOIN [Match] SourcePool ON SourcePool.Id = S.AutoSelectMatchId
WHERE (M.ParentMatchId = @TargetStageMatchId OR M.Id = @TargetStageMatchId)
  AND ISNULL(M.IndividualMatch, 0) = 0
  AND (
        SourcePool.ParentMatchId = @SourceStageMatchId
        OR (S.AutoSelectMatchId IS NULL AND S.PlayerId IS NULL)
      )
ORDER BY M.Id, S.Id;", conn, transaction))
                {
                    cmd.Parameters.Add("@TargetStageMatchId", SqlDbType.Int).Value = targetStageId;
                    cmd.Parameters.Add("@SourceStageMatchId", SqlDbType.Int).Value = sourceStageMatchId;
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            int matchId = Convert.ToInt32(reader["MatchId"]);
                            int? parent = ToNullableInt(reader["TargetStageMatchId"]);
                            result.Add(new StageManualCandidateSeat
                            {
                                SeatId = Convert.ToInt32(reader["SeatId"]),
                                MatchId = matchId,
                                TargetStageMatchId = parent ?? matchId,
                                AutoSelectMatchId = ToNullableInt(reader["AutoSelectMatchId"]),
                                AutoSelectPlace = ToNullableInt(reader["AutoSelectlPlace"]),
                                PlayerId = ToNullableInt(reader["PlayerId"])
                            });
                        }
                    }
                }
            }

            return result
                .GroupBy(x => x.SeatId)
                .Select(x => x.First())
                .ToList();
        }

        private static int GetPoolPlayerCount(
            SqlConnection conn,
            SqlTransaction transaction,
            int poolMatchId)
        {
            using (SqlCommand cmd = new SqlCommand(@"
SELECT COUNT(DISTINCT X.PlayerId)
FROM (
    SELECT S.PlayerId
    FROM Seat S
    WHERE S.MatchId = @PoolMatchId
      AND S.PlayerId IS NOT NULL

    UNION ALL

    SELECT S.PlayerId
    FROM [Match] C
    INNER JOIN Seat S ON S.MatchId = C.Id
    WHERE C.ParentMatchId = @PoolMatchId
      AND S.PlayerId IS NOT NULL
) X;", conn, transaction))
            {
                cmd.Parameters.Add("@PoolMatchId", SqlDbType.Int).Value = poolMatchId;
                object value = cmd.ExecuteScalar();
                return value == null || value == DBNull.Value ? 0 : Convert.ToInt32(value);
            }
        }

        private static StageManualAdvancementState BuildStageManualAdvancementState(
            SqlConnection conn,
            SqlTransaction transaction,
            int sourceStageMatchId)
        {
            string sourceStageName = GetMatchName(conn, transaction, sourceStageMatchId);
            if (sourceStageName == null)
            {
                return null;
            }

            List<int> sourcePoolIds =
                GetStageSourcePoolIds(conn, transaction, sourceStageMatchId);
            if (sourcePoolIds.Count == 0)
            {
                return new StageManualAdvancementState
                {
                    SourceStageMatchId = sourceStageMatchId,
                    SourceStageName = sourceStageName,
                    StageComplete = false
                };
            }

            bool matchesComplete = sourcePoolIds.All(poolId =>
                IsStageCompleteForManualAdvancement(conn, transaction, poolId));

            List<StageManualRouteRecord> routes =
                GetStageManualRouteRecords(conn, transaction, sourceStageMatchId);

            bool placementsResolved = routes.All(x => x.PlayerId.HasValue) &&
                routes.Where(x => x.PlayerId.HasValue)
                    .Select(x => x.PlayerId.Value)
                    .Distinct()
                    .Count() == routes.Count;

            List<StageManualAdvancementPlayerDetails> players = routes
                .Where(x => x.PlayerId.HasValue)
                .Select(x => new StageManualAdvancementPlayerDetails
                {
                    PlayerId = x.PlayerId.Value,
                    PlayerName = x.PlayerName,
                    SourcePoolMatchId = x.SourcePoolMatchId,
                    SourcePoolName = x.SourcePoolName,
                    Place = x.Place,
                    SourcePoolPlayerCount = GetPoolPlayerCount(conn, transaction, x.SourcePoolMatchId),
                    TargetStageMatchId = x.TargetStageMatchId,
                    TargetStageName = x.TargetStageName,
                    CurrentDestinationPoolMatchId = x.DestinationPoolMatchId,
                    CurrentDestinationPoolName = x.DestinationPoolName
                })
                .OrderBy(x => x.TargetStageMatchId)
                .ThenBy(x => x.Place)
                .ThenBy(x => x.SourcePoolMatchId)
                .ToList();

            List<StageManualCandidateSeat> candidateSeats =
                GetStageManualCandidateSeats(conn, transaction, sourceStageMatchId);
            List<StageManualAdvancementPoolDetails> pools = new List<StageManualAdvancementPoolDetails>();

            foreach (int targetStageId in routes.Select(x => x.TargetStageMatchId).Distinct())
            {
                string targetStageName = routes
                    .Where(x => x.TargetStageMatchId == targetStageId)
                    .Select(x => x.TargetStageName)
                    .FirstOrDefault(x => !String.IsNullOrWhiteSpace(x));

                List<Tuple<int, string>> stagePools = new List<Tuple<int, string>>();
                using (SqlCommand cmd = new SqlCommand(@"
SELECT Id, Name
FROM [Match]
WHERE ParentMatchId = @TargetStageMatchId
  AND ISNULL(IndividualMatch, 0) = 0
ORDER BY Id;", conn, transaction))
                {
                    cmd.Parameters.Add("@TargetStageMatchId", SqlDbType.Int).Value = targetStageId;
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            stagePools.Add(Tuple.Create(
                                Convert.ToInt32(reader["Id"]),
                                ToNullableString(reader["Name"])));
                        }
                    }
                }

                if (stagePools.Count == 0)
                {
                    stagePools = routes
                        .Where(x => x.TargetStageMatchId == targetStageId)
                        .Select(x => Tuple.Create(x.DestinationPoolMatchId, x.DestinationPoolName))
                        .GroupBy(x => x.Item1)
                        .Select(x => x.First())
                        .ToList();
                }

                foreach (Tuple<int, string> pool in stagePools)
                {
                    int capacity = candidateSeats.Count(x => x.MatchId == pool.Item1);
                    if (capacity == 0)
                    {
                        continue;
                    }

                    pools.Add(new StageManualAdvancementPoolDetails
                    {
                        MatchId = pool.Item1,
                        MatchName = pool.Item2,
                        TargetStageMatchId = targetStageId,
                        TargetStageName = targetStageName,
                        Capacity = capacity,
                        CurrentAssignedCount = routes.Count(x => x.DestinationPoolMatchId == pool.Item1)
                    });
                }
            }

            return new StageManualAdvancementState
            {
                SourceStageMatchId = sourceStageMatchId,
                SourceStageName = sourceStageName,
                StageComplete = matchesComplete && placementsResolved,
                Players = players,
                Pools = pools
                    .OrderBy(x => x.TargetStageMatchId)
                    .ThenBy(x => x.MatchId)
                    .ToList()
            };
        }

        private static bool IsStageCompleteForManualAdvancement(
            SqlConnection conn,
            SqlTransaction transaction,
            int sourceStageMatchId)
        {
            List<int> childMatchIds = GetChildMatchIds(conn, transaction, sourceStageMatchId);
            if (childMatchIds.Count == 0)
            {
                return false;
            }

            List<ChildSeatResult> childResults = GetChildResults(conn, transaction, sourceStageMatchId);
            foreach (int childMatchId in childMatchIds)
            {
                List<ChildSeatResult> seats = childResults
                    .Where(x => x.MatchId == childMatchId && x.PlayerId > 0)
                    .ToList();

                // One assigned seat is valid for an automatic Swiss bye. Normal
                // two-player and multi-player matches simply have more seats here.
                if (seats.Count == 0 || seats.Any(x => !x.ResultMatchPlace.HasValue))
                {
                    return false;
                }
            }

            return true;
        }

        private static List<ManualAdvancementPlayerDetails> GetManualAdvancementPlayers(
            SqlConnection conn,
            SqlTransaction transaction,
            int sourceStageMatchId)
        {
            List<ManualAdvancementPlayerDetails> result = new List<ManualAdvancementPlayerDetails>();
            using (SqlCommand cmd = new SqlCommand(@"
SELECT
    S.PlayerId,
    P.Name AS PlayerName,
    S.ResultMatchPlace
FROM Seat S
LEFT JOIN Player P ON P.Id = S.PlayerId
WHERE S.MatchId = @SourceStageMatchId
  AND S.PlayerId IS NOT NULL
ORDER BY
    CASE WHEN S.ResultMatchPlace IS NULL THEN 1 ELSE 0 END,
    S.ResultMatchPlace,
    S.Id;", conn, transaction))
            {
                cmd.Parameters.Add("@SourceStageMatchId", SqlDbType.Int).Value = sourceStageMatchId;
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        int playerId = Convert.ToInt32(reader["PlayerId"]);
                        result.Add(new ManualAdvancementPlayerDetails
                        {
                            PlayerId = playerId,
                            PlayerName = reader["PlayerName"] == DBNull.Value
                                ? "Player #" + playerId
                                : Convert.ToString(reader["PlayerName"]),
                            Place = ToNullableInt(reader["ResultMatchPlace"])
                        });
                    }
                }
            }
            return result;
        }

        private static List<ManualAdvancementDestinationDetails> GetConfiguredManualAdvancementDestinations(
            SqlConnection conn,
            SqlTransaction transaction,
            int sourceStageMatchId)
        {
            List<ManualAdvancementDestinationDetails> result =
                new List<ManualAdvancementDestinationDetails>();

            using (SqlCommand cmd = new SqlCommand(@"
SELECT
    S.Id AS SeatId,
    S.MatchId,
    M.Name AS MatchName,
    M.ParentMatchId,
    PM.Name AS ParentMatchName,
    S.AutoSelectlPlace,
    S.PlayerId,
    P.Name AS PlayerName
FROM Seat S
INNER JOIN [Match] M ON M.Id = S.MatchId
LEFT JOIN [Match] PM ON PM.Id = M.ParentMatchId
LEFT JOIN Player P ON P.Id = S.PlayerId
WHERE S.AutoSelectMatchId = @SourceStageMatchId
ORDER BY
    ISNULL(M.ParentMatchId, 0),
    M.Id,
    S.Id;", conn, transaction))
            {
                cmd.Parameters.Add("@SourceStageMatchId", SqlDbType.Int).Value = sourceStageMatchId;

                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        result.Add(new ManualAdvancementDestinationDetails
                        {
                            SeatId = Convert.ToInt32(reader["SeatId"]),
                            MatchId = Convert.ToInt32(reader["MatchId"]),
                            MatchName = reader["MatchName"] == DBNull.Value
                                ? null
                                : Convert.ToString(reader["MatchName"]),
                            ParentMatchId = ToNullableInt(reader["ParentMatchId"]),
                            ParentMatchName = reader["ParentMatchName"] == DBNull.Value
                                ? null
                                : Convert.ToString(reader["ParentMatchName"]),
                            AutoSelectPlace = ToNullableInt(reader["AutoSelectlPlace"]),
                            PlayerId = ToNullableInt(reader["PlayerId"]),
                            PlayerName = reader["PlayerName"] == DBNull.Value
                                ? null
                                : Convert.ToString(reader["PlayerName"]),
                            ConfiguredForSource = true,
                            RequiresPlayerSwap = false
                        });
                    }
                }
            }

            return result;
        }

        private static List<ManualAdvancementDestinationDetails> GetManualAdvancementDestinations(
            SqlConnection conn,
            SqlTransaction transaction,
            int sourceStageMatchId)
        {
            List<ManualAdvancementDestinationDetails> configured =
                GetConfiguredManualAdvancementDestinations(
                    conn,
                    transaction,
                    sourceStageMatchId);

            List<ManualAdvancementDestinationDetails> result =
                new List<ManualAdvancementDestinationDetails>();

            foreach (IGrouping<int, ManualAdvancementDestinationDetails> stageGroup in configured
                .Where(x => x.AutoSelectPlace.HasValue && x.AutoSelectPlace.Value > 0)
                .GroupBy(x => x.ParentMatchId ?? x.MatchId))
            {
                int targetStageId = stageGroup.Key;
                string targetStageName = stageGroup
                    .Select(x => x.ParentMatchName)
                    .FirstOrDefault(x => !String.IsNullOrWhiteSpace(x));

                List<int> qualifyingPlaces = stageGroup
                    .Select(x => x.AutoSelectPlace.Value)
                    .Distinct()
                    .OrderBy(x => x)
                    .ToList();

                List<int> poolIds = new List<int>();

                using (SqlCommand cmd = new SqlCommand(@"
SELECT M.Id
FROM [Match] M
WHERE M.ParentMatchId = @TargetStageId
  AND ISNULL(M.IndividualMatch, 0) = 0
ORDER BY M.Id;", conn, transaction))
                {
                    cmd.Parameters.Add("@TargetStageId", SqlDbType.Int).Value = targetStageId;

                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            poolIds.Add(Convert.ToInt32(reader["Id"]));
                        }
                    }
                }

                if (poolIds.Count == 0)
                {
                    foreach (ManualAdvancementDestinationDetails route in stageGroup)
                    {
                        result.Add(route);
                    }
                    continue;
                }

                foreach (int poolId in poolIds)
                {
                    List<ManualAdvancementSeatCandidate> seats =
                        GetManualAdvancementPoolSeats(
                            conn,
                            transaction,
                            poolId);

                    HashSet<int> usedSeatIds = new HashSet<int>();

                    foreach (int place in qualifyingPlaces)
                    {
                        ManualAdvancementDestinationDetails configuredRoute = stageGroup
                            .FirstOrDefault(x =>
                                x.AutoSelectPlace == place &&
                                x.MatchId == poolId);

                        ManualAdvancementSeatCandidate candidate = null;

                        if (configuredRoute != null)
                        {
                            candidate = seats.FirstOrDefault(x =>
                                x.SeatId == configuredRoute.SeatId);
                        }

                        if (candidate == null)
                        {
                            candidate = seats.FirstOrDefault(x =>
                                !usedSeatIds.Contains(x.SeatId) &&
                                !x.PlayerId.HasValue);
                        }

                        // Even a full pool remains selectable. If all seats are occupied,
                        // choose a route slot belonging to another source pool and swap the
                        // two players when saving. This makes every pool in the next stage
                        // available in the dropdown while preserving pool capacity.
                        if (candidate == null)
                        {
                            candidate = seats.FirstOrDefault(x =>
                                !usedSeatIds.Contains(x.SeatId) &&
                                x.AutoSelectMatchId != sourceStageMatchId);
                        }

                        if (candidate == null)
                        {
                            candidate = seats.FirstOrDefault(x =>
                                !usedSeatIds.Contains(x.SeatId));
                        }

                        if (candidate == null)
                        {
                            continue;
                        }

                        usedSeatIds.Add(candidate.SeatId);

                        bool configuredForSource =
                            candidate.AutoSelectMatchId == sourceStageMatchId &&
                            candidate.AutoSelectPlace == place;

                        result.Add(new ManualAdvancementDestinationDetails
                        {
                            SeatId = candidate.SeatId,
                            MatchId = candidate.MatchId,
                            MatchName = candidate.MatchName,
                            ParentMatchId = candidate.ParentMatchId,
                            ParentMatchName = candidate.ParentMatchName ?? targetStageName,
                            AutoSelectPlace = place,
                            PlayerId = candidate.PlayerId,
                            PlayerName = candidate.PlayerName,
                            ConfiguredForSource = configuredForSource,
                            RequiresPlayerSwap =
                                candidate.PlayerId.HasValue && !configuredForSource
                        });
                    }
                }
            }

            return result
                .OrderBy(x => x.AutoSelectPlace ?? Int32.MaxValue)
                .ThenBy(x => x.ParentMatchId ?? Int32.MaxValue)
                .ThenBy(x => x.MatchId)
                .ThenBy(x => x.SeatId)
                .ToList();
        }

        private static List<ManualAdvancementSeatCandidate> GetManualAdvancementPoolSeats(
            SqlConnection conn,
            SqlTransaction transaction,
            int poolMatchId)
        {
            List<ManualAdvancementSeatCandidate> result =
                new List<ManualAdvancementSeatCandidate>();

            using (SqlCommand cmd = new SqlCommand(@"
SELECT
    S.Id AS SeatId,
    S.MatchId,
    M.Name AS MatchName,
    M.ParentMatchId,
    PM.Name AS ParentMatchName,
    S.AutoSelectMatchId,
    S.AutoSelectlPlace,
    S.PlayerId,
    P.Name AS PlayerName
FROM Seat S
INNER JOIN [Match] M ON M.Id = S.MatchId
LEFT JOIN [Match] PM ON PM.Id = M.ParentMatchId
LEFT JOIN Player P ON P.Id = S.PlayerId
WHERE S.MatchId = @PoolMatchId
ORDER BY S.Id;", conn, transaction))
            {
                cmd.Parameters.Add("@PoolMatchId", SqlDbType.Int).Value = poolMatchId;

                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        result.Add(new ManualAdvancementSeatCandidate
                        {
                            SeatId = Convert.ToInt32(reader["SeatId"]),
                            MatchId = Convert.ToInt32(reader["MatchId"]),
                            MatchName = reader["MatchName"] == DBNull.Value
                                ? null
                                : Convert.ToString(reader["MatchName"]),
                            ParentMatchId = ToNullableInt(reader["ParentMatchId"]),
                            ParentMatchName = reader["ParentMatchName"] == DBNull.Value
                                ? null
                                : Convert.ToString(reader["ParentMatchName"]),
                            AutoSelectMatchId = ToNullableInt(reader["AutoSelectMatchId"]),
                            AutoSelectPlace = ToNullableInt(reader["AutoSelectlPlace"]),
                            PlayerId = ToNullableInt(reader["PlayerId"]),
                            PlayerName = reader["PlayerName"] == DBNull.Value
                                ? null
                                : Convert.ToString(reader["PlayerName"])
                        });
                    }
                }
            }

            return result;
        }

        private static SeatRoutingDetails GetSeatRoutingDetails(
            SqlConnection conn,
            SqlTransaction transaction,
            int seatId)
        {
            using (SqlCommand cmd = new SqlCommand(@"
SELECT
    Id,
    MatchId,
    AutoSelectMatchId,
    AutoSelectlPlace,
    PlayerId
FROM Seat
WHERE Id = @SeatId;", conn, transaction))
            {
                cmd.Parameters.Add("@SeatId", SqlDbType.Int).Value = seatId;

                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (!reader.Read())
                    {
                        return null;
                    }

                    return new SeatRoutingDetails
                    {
                        SeatId = Convert.ToInt32(reader["Id"]),
                        MatchId = Convert.ToInt32(reader["MatchId"]),
                        AutoSelectMatchId = ToNullableInt(reader["AutoSelectMatchId"]),
                        AutoSelectPlace = ToNullableInt(reader["AutoSelectlPlace"]),
                        PlayerId = ToNullableInt(reader["PlayerId"])
                    };
                }
            }
        }

        private static void SwapSeatAutoSelection(
            SqlConnection conn,
            SqlTransaction transaction,
            SeatRoutingDetails first,
            SeatRoutingDetails second)
        {
            using (SqlCommand cmd = new SqlCommand(@"
UPDATE Seat
SET AutoSelectMatchId = @SecondMatchId,
    AutoSelectlPlace = @SecondPlace
WHERE Id = @FirstSeatId;

UPDATE Seat
SET AutoSelectMatchId = @FirstMatchId,
    AutoSelectlPlace = @FirstPlace
WHERE Id = @SecondSeatId;", conn, transaction))
            {
                cmd.Parameters.Add("@FirstSeatId", SqlDbType.Int).Value = first.SeatId;
                cmd.Parameters.Add("@SecondSeatId", SqlDbType.Int).Value = second.SeatId;

                cmd.Parameters.Add("@SecondMatchId", SqlDbType.Int).Value =
                    second.AutoSelectMatchId.HasValue
                        ? (object)second.AutoSelectMatchId.Value
                        : DBNull.Value;
                cmd.Parameters.Add("@SecondPlace", SqlDbType.Int).Value =
                    second.AutoSelectPlace.HasValue
                        ? (object)second.AutoSelectPlace.Value
                        : DBNull.Value;

                cmd.Parameters.Add("@FirstMatchId", SqlDbType.Int).Value =
                    first.AutoSelectMatchId.HasValue
                        ? (object)first.AutoSelectMatchId.Value
                        : DBNull.Value;
                cmd.Parameters.Add("@FirstPlace", SqlDbType.Int).Value =
                    first.AutoSelectPlace.HasValue
                        ? (object)first.AutoSelectPlace.Value
                        : DBNull.Value;

                cmd.ExecuteNonQuery();
            }
        }

        private static List<DestinationSeat> GetDestinationSeats(
            SqlConnection conn,
            SqlTransaction transaction,
            int sourceStageMatchId,
            int place)
        {
            List<DestinationSeat> result = new List<DestinationSeat>();
            using (SqlCommand cmd = new SqlCommand(@"
SELECT S.Id, S.MatchId, S.PlayerId, M.Name AS MatchName
FROM Seat S
INNER JOIN [Match] M ON M.Id = S.MatchId
WHERE S.AutoSelectMatchId = @SourceStageMatchId
  AND S.AutoSelectlPlace = @Place
ORDER BY S.Id;", conn, transaction))
            {
                cmd.Parameters.Add("@SourceStageMatchId", SqlDbType.Int).Value = sourceStageMatchId;
                cmd.Parameters.Add("@Place", SqlDbType.Int).Value = place;
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        result.Add(new DestinationSeat
                        {
                            SeatId = Convert.ToInt32(reader["Id"]),
                            MatchId = Convert.ToInt32(reader["MatchId"]),
                            MatchName = reader["MatchName"] == DBNull.Value ? null : Convert.ToString(reader["MatchName"]),
                            PlayerId = ToNullableInt(reader["PlayerId"])
                        });
                    }
                }
            }
            return result;
        }

        private static List<DestinationSeat> GetAllDestinationSeats(
            SqlConnection conn,
            SqlTransaction transaction,
            int sourceStageMatchId)
        {
            List<DestinationSeat> result = new List<DestinationSeat>();
            using (SqlCommand cmd = new SqlCommand(@"
SELECT S.Id, S.MatchId, S.PlayerId, M.Name AS MatchName
FROM Seat S
INNER JOIN [Match] M ON M.Id = S.MatchId
WHERE S.AutoSelectMatchId = @SourceStageMatchId
ORDER BY S.Id;", conn, transaction))
            {
                cmd.Parameters.Add("@SourceStageMatchId", SqlDbType.Int).Value = sourceStageMatchId;
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        result.Add(new DestinationSeat
                        {
                            SeatId = Convert.ToInt32(reader["Id"]),
                            MatchId = Convert.ToInt32(reader["MatchId"]),
                            MatchName = reader["MatchName"] == DBNull.Value ? null : Convert.ToString(reader["MatchName"]),
                            PlayerId = ToNullableInt(reader["PlayerId"])
                        });
                    }
                }
            }
            return result;
        }

        private static int? ToNullableInt(object value)
        {
            return value == null || value == DBNull.Value ? (int?)null : Convert.ToInt32(value);
        }

        private static string ToNullableString(object value)
        {
            return value == null || value == DBNull.Value ? null : Convert.ToString(value);
        }

        private static DateTime? ToNullableDateTime(object value)
        {
            return value == null || value == DBNull.Value ? (DateTime?)null : Convert.ToDateTime(value);
        }
    }
}
